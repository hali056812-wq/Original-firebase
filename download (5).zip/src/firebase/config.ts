export const firebaseConfig = {
  "projectId": "studio-5255076939-b2790",
  "appId": "1:156533184432:web:9dfab69a8703cf0d6be875",
  "apiKey": "AIzaSyBUSZAyrgTJo-VGqbEcQARgpjl7-QxZ8QE",
  "authDomain": "studio-5255076939-b2790.firebaseapp.com",
  "measurementId": "",
  "messagingSenderId": "156533184432"
};
