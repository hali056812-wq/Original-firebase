'use server';
import {ai} from '@/ai/genkit';
import {z} from 'genkit';

const WeatherToolInputSchema = z.object({
  location: z
    .string()
    .describe(
      'The city name and state code (e.g., "San Francisco, CA") or ZIP code.'
    ),
});

const WeatherToolOutputSchema = z.object({
  temperature: z.number().describe('Temperature in Celsius.'),
  temperatureFahrenheit: z.number().describe('Temperature in Fahrenheit.'),
  conditions: z.string().describe('Weather conditions (e.g., "Clear", "Clouds").'),
  humidity: z.number().describe('Humidity percentage.'),
  windSpeed: z.number().describe('Wind speed in meter/sec.'),
});

export const getOpenWeatherMapData = ai.defineTool(
  {
    name: 'getOpenWeatherMapData',
    description: 'Fetches current weather data from OpenWeatherMap.',
    inputSchema: WeatherToolInputSchema,
    outputSchema: WeatherToolOutputSchema.nullable(),
  },
  async input => {
    const apiKey = process.env.OPENWEATHERMAP_API_KEY;
    if (!apiKey) {
      // This will be handled in the flow, no need to log here.
      return null;
    }

    const isZipCode = /^\d{5}(-\d{4})?$/.test(input.location);
    const queryParam = isZipCode
      ? `zip=${input.location}`
      : `q=${input.location}`;
    const url = `https://api.openweathermap.org/data/2.5/weather?${queryParam}&appid=${apiKey}&units=metric`;

    try {
      const response = await fetch(url);
      
      if (!response.ok) {
        return null;
      }
      const data = await response.json();

      const tempC = data.main.temp;
      const tempF = (tempC * 9) / 5 + 32;

      return {
        temperature: tempC,
        temperatureFahrenheit: tempF,
        conditions: data.weather[0]?.main || 'N/A',
        humidity: data.main.humidity,
        windSpeed: data.wind.speed,
      };
    } catch (error: any) {
      // The flow will handle the null return.
      return null;
    }
  }
);
