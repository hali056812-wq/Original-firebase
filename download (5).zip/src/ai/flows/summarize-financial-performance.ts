'use server';
/**
 * @fileOverview AI agent to summarize financial performance for a farm.
 *
 * - summarizeFinancialPerformance - A function that analyzes financial data and returns a summary.
 * - SummarizeFinancialPerformanceInput - The input type for the function.
 * - SummarizeFinancialPerformanceOutput - The return type for the function.
 */

import {ai} from '@/ai/genkit';
import {z} from 'genkit';

const FieldFinancialsSchema = z.object({
  fieldName: z.string(),
  sales: z.number(),
  costs: z.number(),
  profit: z.number(),
});

const SummarizeFinancialPerformanceInputSchema = z.object({
  totalSales: z.number(),
  totalCosts: z.number(),
  totalProfit: z.number(),
  fieldBreakdown: z.array(FieldFinancialsSchema),
  currency: z.string().default('USD'),
});

export type SummarizeFinancialPerformanceInput = z.infer<typeof SummarizeFinancialPerformanceInputSchema>;

const SummarizeFinancialPerformanceOutputSchema = z.object({
  summary: z.string().describe('A concise, insightful summary of the financial performance.'),
});

export type SummarizeFinancialPerformanceOutput = z.infer<typeof SummarizeFinancialPerformanceOutputSchema>;

export async function summarizeFinancialPerformance(input: SummarizeFinancialPerformanceInput): Promise<SummarizeFinancialPerformanceOutput> {
  return summarizeFinancialPerformanceFlow(input);
}

const prompt = ai.definePrompt({
  name: 'summarizeFinancialPerformancePrompt',
  input: {schema: SummarizeFinancialPerformanceInputSchema},
  output: {schema: SummarizeFinancialPerformanceOutputSchema},
  config: {
    temperature: 0,
  },
  prompt: `You are an expert agricultural financial analyst. Your goal is to provide a brief, easy-to-understand summary of a farmer's financial performance.

Analyze the following data. All monetary values are in {{{currency}}}.

**Overall Performance:**
- Total Sales: {{{totalSales}}}
- Total Costs: {{{totalCosts}}}
- Total Profit: {{{totalProfit}}}

**Field-by-Field Breakdown:**
{{#each fieldBreakdown}}
- Field: "{{fieldName}}"
  - Sales: {{{sales}}}
  - Costs: {{{costs}}}
  - Profit: {{{profit}}}
{{/each}}

Based on this data, provide a 2-3 sentence summary. Start with a general statement about the overall profitability. Then, highlight the most profitable field if there is one, or mention if profits are evenly distributed. Keep the tone encouraging but realistic. Do not use markdown formatting in your response.`,
});

const summarizeFinancialPerformanceFlow = ai.defineFlow(
  {
    name: 'summarizeFinancialPerformanceFlow',
    inputSchema: SummarizeFinancialPerformanceInputSchema,
    outputSchema: SummarizeFinancialPerformanceOutputSchema,
  },
  async input => {
    // Do not run the flow if there's no activity
    if (input.totalSales === 0 && input.totalCosts === 0) {
        return { summary: "No financial activity to analyze yet. Add some sales or costs to get your AI summary." };
    }

    const {output} = await prompt(input);
    return output!;
  }
);
