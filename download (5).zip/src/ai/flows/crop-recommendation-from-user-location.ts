'use server';

/**
 * @fileOverview Provides crop recommendations based on user-provided location, soil data, and climate conditions.
 *
 * - getCropRecommendations - A function that takes location data and returns crop recommendations.
 * - CropRecommendationInput - The input type for the getCropRecommendations function.
 * - CropRecommendationOutput - The return type for the getCropRecommendations function.
 */

import {ai} from '@/ai/genkit';
import {z} from 'genkit';

const CropRecommendationInputSchema = z.object({
  location: z.string().describe('The geographical location of the farm.'),
  soilData: z.string().describe('The data of the soil at the farm location.'),
  climateConditions: z.string().describe('The climate conditions at the farm location.'),
});

export type CropRecommendationInput = z.infer<typeof CropRecommendationInputSchema>;

const CropRecommendationOutputSchema = z.object({
  cropRecommendations: z.array(
    z.object({
      cropName: z.string().describe('The name of the recommended crop.'),
      season: z.string().describe('The optimal season for planting the crop.'),
      yield: z.string().describe('The expected yield of the crop.'),
      revenue: z.string().describe('The potential revenue from the crop.'),
      waterNeeds: z.string().describe('The water requirements of the crop.'),
      sunlight: z.string().describe('The sunlight requirements of the crop.'),
      difficulty: z.string().describe('The difficulty level of growing the crop.'),
    })
  ).describe('A list of crop recommendations based on the input data.'),
});

export type CropRecommendationOutput = z.infer<typeof CropRecommendationOutputSchema>;

export async function getCropRecommendations(input: CropRecommendationInput): Promise<CropRecommendationOutput> {
  return cropRecommendationFlow(input);
}

const cropRecommendationPrompt = ai.definePrompt({
  name: 'cropRecommendationPrompt',
  input: {schema: CropRecommendationInputSchema},
  output: {schema: CropRecommendationOutputSchema},
  prompt: `You are an expert agricultural advisor. Based on the farmer's location, soil data, and climate conditions, recommend the best crops to plant.

Location: {{{location}}}
Soil Data: {{{soilData}}}
Climate Conditions: {{{climateConditions}}}

Provide a detailed list of crop recommendations, including the optimal season, expected yield, potential revenue, water needs, sunlight requirements, and difficulty level for each crop.  Format the output as a JSON array of crop recommendations.  Each object in the array should include cropName, season, yield, revenue, waterNeeds, sunlight, and difficulty.
`,
});

const cropRecommendationFlow = ai.defineFlow(
  {
    name: 'cropRecommendationFlow',
    inputSchema: CropRecommendationInputSchema,
    outputSchema: CropRecommendationOutputSchema,
  },
  async input => {
    const {output} = await cropRecommendationPrompt(input);
    return output!;
  }
);
