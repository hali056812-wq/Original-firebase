'use server';

/**
 * @fileOverview AI agent to answer questions about farming practices, with conversational memory.
 *
 * - answerFarmingQuestion - A function that answers the farming question, considering chat history.
 * - AnswerFarmingQuestionInput - The input type for the answerFarmingQuestion function.
 * - AnswerFarmingQuestionOutput - The return type for the answerFarmingQuestion function.
 */

import {ai} from '@/ai/genkit';
import {z} from 'genkit';

const AnswerFarmingQuestionInputSchema = z.object({
  question: z.string().describe('The farming question to be answered.'),
  chatHistory: z.array(z.object({
    role: z.enum(['user', 'assistant']),
    content: z.string(),
  })).optional().describe('The previous chat history.'),
});
export type AnswerFarmingQuestionInput = z.infer<typeof AnswerFarmingQuestionInputSchema>;

const AnswerFarmingQuestionOutputSchema = z.object({
  summary: z.string().describe('A 2-3 sentence easy-to-understand summary of the answer.'),
  bulletPoints: z.array(z.string()).describe('A few bullet points outlining the key information or steps.'),
  conclusion: z.string().describe('A concluding sentence to wrap up the answer.'),
});
export type AnswerFarmingQuestionOutput = z.infer<typeof AnswerFarmingQuestionOutputSchema>;

export async function answerFarmingQuestion(input: AnswerFarmingQuestionInput): Promise<AnswerFarmingQuestionOutput> {
  return answerFarmingQuestionFlow(input);
}

const prompt = ai.definePrompt({
  name: 'answerFarmingQuestionPrompt',
  input: {schema: AnswerFarmingQuestionInputSchema},
  output: {schema: AnswerFarmingQuestionOutputSchema},
  prompt: `You are a helpful AI assistant for farmers who is great at explaining things simply. Use everyday language and avoid big words.

Answer the user's question based on the context of the chat history.

Chat History:
{{#if chatHistory}}
{{#each chatHistory}}
{{this.role}}: {{{this.content}}}
{{/each}}
{{/if}}

User's new question: "{{{question}}}"

Structure your response in three parts:
1.  A short summary (2-3 sentences) that gets straight to the point.
2.  A few bullet points with the most important details or simple steps.
3.  A final, encouraging concluding sentence.`,
});

const answerFarmingQuestionFlow = ai.defineFlow(
  {
    name: 'answerFarmingQuestionFlow',
    inputSchema: AnswerFarmingQuestionInputSchema,
    outputSchema: AnswerFarmingQuestionOutputSchema,
  },
  async input => {
    const {output} = await prompt(input);
    return output!;
  }
);
