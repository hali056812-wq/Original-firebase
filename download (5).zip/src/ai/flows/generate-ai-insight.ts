'use server';
/**
 * @fileOverview Generates a brief, conversational insight about the user's farm or garden based on a randomly selected "flavor".
 *
 * - generateAiInsight - A function that generates the AI insight.
 * - GenerateAiInsightInput - The input type for the function.
 * - GenerateAiInsightOutput - The return type for the function.
 */

import {ai} from '@/ai/genkit';
import {z} from 'genkit';

const GenerateAiInsightInputSchema = z.object({
  userType: z.enum(['commercial', 'hobbyist']).default('commercial').describe("The type of user, which tailors the tone and content of the insight."),
  location: z.string().optional().describe("The user's farm location (for weather/seasonal lenses)."),
  season: z.string().optional().describe("The current season (for seasonal lens)."),
  crops: z.array(z.string()).optional().describe("List of crops (for agronomic/seasonal lenses)."),
  profitStatus: z.enum(['positive', 'negative', 'neutral']).optional().describe("The farm's recent profit status (for financial lens)."),
  recentTransactionsCount: z.number().optional().describe("Number of transactions in the last 7 days (for financial lens)."),
  tasks: z.object({
    pending: z.number(),
    completed: z.number(),
  }).optional().describe("Summary of tasks (for productivity lens)."),
});
export type GenerateAiInsightInput = z.infer<typeof GenerateAiInsightInputSchema>;

const GenerateAiInsightOutputSchema = z.object({
  insight: z.string().describe("A single, fresh, conversational sentence providing an insight based on the chosen flavor."),
});
export type GenerateAiInsightOutput = z.infer<typeof GenerateAiInsightOutputSchema>;


const FLAVORS = ['money', 'weather', 'joke', 'micro-tip', 'emoji-story', 'question'] as const;
type Flavor = typeof FLAVORS[number];

const FlavorInputSchema = GenerateAiInsightInputSchema.extend({
    money: z.boolean().optional(),
    weather: z.boolean().optional(),
    joke: z.boolean().optional(),
    'micro-tip': z.boolean().optional(),
    'emoji-story': z.boolean().optional(),
    question: z.boolean().optional(),
});
type FlavorInput = z.infer<typeof FlavorInputSchema>;

export async function generateAiInsight(input: GenerateAiInsightInput): Promise<GenerateAiInsightOutput> {
  // 1. "Roll the dice" to pick a flavor
  const flavor = FLAVORS[Math.floor(Math.random() * FLAVORS.length)];

  // 2. Build the input for the prompt, enabling the chosen flavor
  const flavorInput: FlavorInput = {
    ...input,
    [flavor]: true,
  };
  
  const hasData = input.profitStatus !== undefined || 
                  (input.tasks && (input.tasks.pending > 0 || input.tasks.completed > 0)) || 
                  input.location || 
                  (input.crops && input.crops.length > 0);

  if (!hasData) {
      if (input.userType === 'hobbyist') {
          return { insight: "Welcome! Add some plants or tasks to get personalized gardening tips." };
      }
      return { insight: "Welcome to your farm dashboard! Add some details to get personalized insights." };
  }

  // 3. Call the prompt with the specific flavor activated
  const {output} = await prompt(flavorInput);
  return output!;
}


const prompt = ai.definePrompt({
  name: 'generateAiInsightPrompt',
  input: {schema: FlavorInputSchema},
  output: {schema: GenerateAiInsightOutputSchema},
  config: {
    temperature: 0.9, // Higher temperature for more creative, less repetitive output
  },
  prompt: `You are a friendly and creative AI farm/garden assistant. Your goal is to provide a single, engaging, and fresh sentence that makes the user feel like you're keeping an eye on their operation.

The user is a {{{userType}}} farmer.

You MUST choose ONE of the following "flavors" to generate your response. Use the data provided for that flavor to make your response relevant.

{{#if money}}
### Flavor: Money
- **Style**: A quick financial observation. Encouraging but realistic.
- **Data**: Profit status is '{{{profitStatus}}}'. {{{recentTransactionsCount}}} transactions in the last week.
- **Example**: "Good to see sales are trending positive this week; keeping the momentum up is key for a strong quarter."
- **Generate a 'Money' insight now.**
{{/if}}

{{#if weather}}
### Flavor: Weather
- **Style**: A timely comment about the local weather.
- **Data**: Location is '{{{location}}}'.
- **Example**: "The forecast for {{{location}}} looks clear; it could be a perfect window for that big field task."
- **Generate a 'Weather' insight now.**
{{/if}}

{{#if joke}}
### Flavor: Joke
- **Style**: A lighthearted, farm-related joke or pun that relates to the user's data.
- **Data**: Main crops are {{#each crops}}{{{this}}}, {{/each}}. The season is {{{season}}}. Location is {{{location}}}.
- **Example**: "Why did the scarecrow win an award? Because he was outstanding in his field!"
- **Generate a 'Joke' insight now, making it relevant to the user's data if possible.**
{{/if}}

{{#if micro-tip}}
### Flavor: Micro-Tip
- **Style**: A single, actionable, and very short tip related to the user's crops.
- **Data**: Main crops are {{#each crops}}{{{this}}}, {{/each}}.
- **Example**: "Pinching the tops of your basil plants will encourage them to grow even bushier."
- **Generate a 'Micro-Tip' insight now.**
{{/if}}

{{#if emoji-story}}
### Flavor: Emoji Story
- **Style**: Tell a tiny story about the farm using only 3-5 emojis.
- **Data**: You have {{{tasks.pending}}} tasks to do and {{{tasks.completed}}} completed. The season is {{{season}}}.
- **Example**: "🌱➡️☀️➡️🌽"
- **Generate an 'Emoji Story' insight now.**
{{/if}}

{{#if question}}
### Flavor: Question
- **Style**: A thought-provoking question to get the user thinking about their farm/garden.
- **Data**: The season is {{{season}}}. Main crops are {{#each crops}}{{{this}}}, {{/each}}.
- **Example**: "As {{{season}}} settles in, have you thought about what cover crops you might plant for the offseason?"
- **Generate a 'Question' insight now.**
{{/if}}

Your response MUST be a single sentence and fit the chosen flavor.
`,
});
