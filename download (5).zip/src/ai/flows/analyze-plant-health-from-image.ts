'use server';
/**
 * @fileOverview Analyzes plant health from an image and provides a diagnosis.
 *
 * - analyzePlantHealthFromImage - A function that handles the plant health analysis process.
 * - AnalyzePlantHealthFromImageInput - The input type for the analyzePlantHealthFromImage function.
 * - AnalyzePlantHealthFromImageOutput - The return type for the analyzePlantHealthFromImage function.
 */

import {ai} from '@/ai/genkit';
import {z} from 'genkit';

const AnalyzePlantHealthFromImageInputSchema = z.object({
  photoDataUri: z
    .string()
    .describe(
      "A photo of a plant, as a data URI that must include a MIME type and use Base64 encoding. Expected format: 'data:<mimetype>;base64,<encoded_data>'."
    ),
});
export type AnalyzePlantHealthFromImageInput = z.infer<typeof AnalyzePlantHealthFromImageInputSchema>;

const AnalyzePlantHealthFromImageOutputSchema = z.object({
  summary: z.string().describe('A 2-3 sentence easy-to-understand summary of the diagnosis.'),
  bulletPoints: z.array(z.string()).describe('A few bullet points outlining the key findings or recommended actions.'),
  conclusion: z.string().describe('A concluding sentence to wrap up the diagnosis.'),
});
export type AnalyzePlantHealthFromImageOutput = z.infer<typeof AnalyzePlantHealthFromImageOutputSchema>;

export async function analyzePlantHealthFromImage(input: AnalyzePlantHealthFromImageInput): Promise<AnalyzePlantHealthFromImageOutput> {
  return analyzePlantHealthFromImageFlow(input);
}

const prompt = ai.definePrompt({
  name: 'analyzePlantHealthFromImagePrompt',
  input: {schema: AnalyzePlantHealthFromImageInputSchema},
  output: {schema: AnalyzePlantHealthFromImageOutputSchema},
  prompt: `You are an expert botanist specializing in diagnosing plant illnesses from images, but you're explaining it to a beginner. Use simple, everyday language and avoid technical jargon.

Based on the image provided, diagnose the plant's health. Structure your response in three parts:
1.  A short summary (2-3 sentences) of the main issue.
2.  A few bullet points with the most important details or simple steps to take.
3.  A final, encouraging concluding sentence.

Image: {{media url=photoDataUri}}`,
});

const analyzePlantHealthFromImageFlow = ai.defineFlow(
  {
    name: 'analyzePlantHealthFromImageFlow',
    inputSchema: AnalyzePlantHealthFromImageInputSchema,
    outputSchema: AnalyzePlantHealthFromImageOutputSchema,
  },
  async input => {
    const {output} = await prompt(input);
    return output!;
  }
);
