'use server';

/**
 * @fileOverview AI agent to answer follow-up questions about a plant diagnosis.
 *
 * - answerPlantDiagnosisQuestion - A function that answers a follow-up question.
 * - AnswerPlantDiagnosisQuestionInput - The input type for the function.
 * - AnswerPlantDiagnosisQuestionOutput - The return type for the function.
 */

import {ai} from '@/ai/genkit';
import {z} from 'genkit';
import { AnalyzePlantHealthFromImageOutput } from './analyze-plant-health-from-image';

const AnswerPlantDiagnosisQuestionInputSchema = z.object({
  photoDataUri: z.string().describe("The data URI of the plant photo."),
  diagnosis: z.string().describe('The initial diagnosis of the plant health.'),
  question: z.string().describe('The follow-up question from the user.'),
  chatHistory: z.array(z.object({
    role: z.enum(['user', 'assistant']),
    content: z.string(),
  })).optional().describe('The previous chat history.'),
});
export type AnswerPlantDiagnosisQuestionInput = z.infer<typeof AnswerPlantDiagnosisQuestionInputSchema>;

const AnswerPlantDiagnosisQuestionOutputSchema = z.object({
  summary: z.string().describe('A 2-3 sentence easy-to-understand summary of the answer.'),
  bulletPoints: z.array(z.string()).describe('A few bullet points outlining the key information or steps.'),
  conclusion: z.string().describe('A concluding sentence to wrap up the answer.'),
});
export type AnswerPlantDiagnosisQuestionOutput = z.infer<typeof AnswerPlantDiagnosisQuestionOutputSchema>;

export async function answerPlantDiagnosisQuestion(input: AnswerPlantDiagnosisQuestionInput): Promise<AnswerPlantDiagnosisQuestionOutput> {
  return answerPlantDiagnosisQuestionFlow(input);
}

const prompt = ai.definePrompt({
  name: 'answerPlantDiagnosisQuestionPrompt',
  input: {schema: AnswerPlantDiagnosisQuestionInputSchema},
  output: {schema: AnswerPlantDiagnosisQuestionOutputSchema},
  prompt: `You are an expert botanist who is great at explaining things simply to beginners. Use everyday language and avoid big words.

You have already provided an initial diagnosis for a plant. The user now has a follow-up question.

Here is the context:
Initial Diagnosis: "{{diagnosis}}"
User's Question: "{{{question}}}"

Chat History:
{{#if chatHistory}}
{{#each chatHistory}}
{{this.role}}: {{{this.content}}}
{{/each}}
{{/if}}

Analyze the user's question in the context of the image, the diagnosis, and the chat history. Provide a clear and helpful answer structured in three parts:
1. A short summary (2-3 sentences).
2. A few bullet points with the most important details.
3. A final, encouraging concluding sentence.

Image of the plant:
{{media url=photoDataUri}}
`,
});

const answerPlantDiagnosisQuestionFlow = ai.defineFlow(
  {
    name: 'answerPlantDiagnosisQuestionFlow',
    inputSchema: AnswerPlantDiagnosisQuestionInputSchema,
    outputSchema: AnswerPlantDiagnosisQuestionOutputSchema,
  },
  async input => {
    const {output} = await prompt(input);
    return output!;
  }
);
