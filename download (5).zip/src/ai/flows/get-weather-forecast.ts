'use server';

/**
 * @fileOverview Provides a weather forecast for a given location, including potential crop-related alerts.
 *
 * - getWeatherForecast - A function that takes a location and returns a weather forecast.
 * - GetWeatherForecastInput - The input type for the getWeatherForecast function.
 * - GetWeatherForecastOutput - The return type for the getWeatherForecast function.
 */

import {ai} from '@/ai/genkit';
import {z} from 'genkit';
import {getOpenWeatherMapData} from '@/ai/tools/weather';

const GetWeatherForecastInputSchema = z.object({
  location: z.string().describe('The location for which to get the weather forecast.'),
});
export type GetWeatherForecastInput = z.infer<typeof GetWeatherForecastInputSchema>;

const GetWeatherForecastOutputSchema = z.object({
  forecast: z.object({
    temperature: z.number().describe('The current temperature in Celsius.'),
    temperatureFahrenheit: z.number().describe('The current temperature in Fahrenheit.'),
    conditions: z.string().describe('The current weather conditions (e.g., Sunny, Cloudy, Rainy).'),
    humidity: z.number().describe('The current humidity percentage.'),
    windSpeed: z.number().describe('The current wind speed in km/h.'),
    alerts: z.array(z.object({
      type: z.string().describe('Type of alert (e.g., Frost, Drought, Storm).'),
      severity: z.string().describe('Severity of the alert (e.g., Warning, Watch, Advisory).'),
      description: z.string().describe('A brief description of the alert.'),
    })).optional().describe('Any emergency weather alerts for the location that could impact crops, like frost, drought, or storms. This should only be populated if there is an active, relevant alert.'),
  }).nullable(),
  error: z.string().optional().describe('An error message if the weather data could not be fetched.'),
});
export type GetWeatherForecastOutput = z.infer<typeof GetWeatherForecastOutputSchema>;

export async function getWeatherForecast(input: GetWeatherForecastInput): Promise<GetWeatherForecastOutput> {
  return getWeatherForecastFlow(input);
}

const getWeatherForecastFlow = ai.defineFlow(
  {
    name: 'getWeatherForecastFlow',
    inputSchema: GetWeatherForecastInputSchema,
    outputSchema: GetWeatherForecastOutputSchema,
  },
  async (input) => {
    // Call the tool directly to fetch weather data.
    const weatherData = await getOpenWeatherMapData(input);

    if (weatherData === null) {
      // If the tool returns null, immediately return an error object that fits the schema.
      return {
        forecast: null,
        error: 'The weather service may be unavailable or the location is invalid. Please ensure your OpenWeatherMap API key is set in the .env file and the location is correct.',
      };
    }
    
    // Manually process the data here instead of making another AI call.
    const windSpeedKmh = weatherData.windSpeed * 3.6;

    // Simple logic to generate alerts. This can be expanded.
    const alerts: GetWeatherForecastOutput['forecast']['alerts'] = [];
    if (weatherData.temperature < 2) {
        alerts.push({
            type: 'Frost Advisory',
            severity: 'Advisory',
            description: 'Temperatures are near freezing. Protect sensitive plants from potential frost damage.'
        });
    }
    if (windSpeedKmh > 50) {
        alerts.push({
            type: 'High Wind',
            severity: 'Warning',
            description: `High winds of ${Math.round(windSpeedKmh)} km/h may damage crops or lightweight structures.`
        });
    }

    const output: GetWeatherForecastOutput = {
        forecast: {
            ...weatherData,
            windSpeed: windSpeedKmh, // Use the converted value
            alerts: alerts,
        },
    };

    return output;
  }
);
