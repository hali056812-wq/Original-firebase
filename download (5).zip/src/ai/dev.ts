'use server';
import { config } from 'dotenv';
config();

import '@/ai/flows/crop-recommendation-from-user-location.ts';
import '@/ai/flows/analyze-plant-health-from-image.ts';
import '@/ai/flows/answer-farming-questions.ts';
import '@/ai/flows/get-weather-forecast.ts';
import '@/ai/flows/answer-plant-diagnosis-question.ts';
import '@/ai/flows/summarize-financial-performance.ts';
import '@/ai/flows/generate-ai-insight.ts';
import '@/ai/tools/weather.ts';
