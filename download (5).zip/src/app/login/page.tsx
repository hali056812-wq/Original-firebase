import { MarketingHeader } from '@/components/marketing/header';
import { LoginForm } from '@/components/auth/login-form';
import { Card, CardHeader, CardTitle, CardDescription, CardContent } from '@/components/ui/card';
import Link from 'next/link';

export default function LoginPage() {
  return (
    <div className="flex flex-col min-h-screen">
        <MarketingHeader />
        <main className="flex-1 flex items-center justify-center">
            <Card className="w-full max-w-md mx-4">
            <CardHeader className="text-center">
                <CardTitle className="text-2xl font-headline">Welcome Back</CardTitle>
                <CardDescription>Sign in to access your farm dashboard</CardDescription>
            </CardHeader>
            <CardContent>
                <LoginForm />
                <div className="mt-4 text-center text-sm">
                Don&apos;t have an account?{' '}
                <Link href="/signup" className="underline">
                    Sign up
                </Link>
                </div>
            </CardContent>
            </Card>
        </main>
    </div>
  );
}
