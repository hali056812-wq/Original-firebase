'use client';

import Link from 'next/link';
import { Button } from '@/components/ui/button';
import { ArrowRight, Bot, Leaf } from 'lucide-react';
import { MarketingHeader } from '@/components/marketing/header';
import { MarketingFooter } from '@/components/marketing/footer';

export default function HomePage() {
  const handleAssistantClick = () => {
    // This could be improved to deep link to the right tab
    window.location.href = '/dashboard?tab=assistant';
  };

  return (
    <div className="flex flex-col min-h-screen">
      <MarketingHeader />
      <main className="flex-1">
        <section className="w-full py-12 md:py-24 lg:py-32 xl:py-48">
          <div className="container px-4 md:px-6">
            <div className="flex flex-col items-center space-y-4 text-center">
              <div className="space-y-6">
                <h1 className="text-4xl font-bold tracking-tighter sm:text-5xl md:text-6xl lg:text-7xl font-headline text-primary">
                  Smart Farm Assistant
                </h1>
                <p className="mx-auto max-w-[700px] text-muted-foreground md:text-xl">
                  Get personalized crop recommendations, expert farming advice, and instant plant health analysis.
                </p>
              </div>
              <div className="space-x-4 pt-6">
                <Link href="/dashboard">
                  <Button size="lg">
                    <Leaf className="mr-2 h-5 w-5" />
                    Start Planning My Farm
                    <ArrowRight className="ml-2 h-5 w-5" />
                  </Button>
                </Link>
                <Button size="lg" variant="secondary" onClick={handleAssistantClick}>
                  <Bot className="mr-2 h-5 w-5" />
                  Get Farming Advice
                </Button>
              </div>
            </div>
          </div>
        </section>
      </main>
      <MarketingFooter />
    </div>
  );
}
