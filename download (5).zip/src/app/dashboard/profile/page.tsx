'use client';

import { zodResolver } from '@hookform/resolvers/zod';
import { useForm } from 'react-hook-form';
import { z } from 'zod';
import { Button } from '@/components/ui/button';
import {
  Form,
  FormControl,
  FormDescription,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from '@/components/ui/form';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { useFarmData } from '@/hooks/use-farm-data';
import { useAuth } from '@/hooks/use-auth';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { useToast } from '@/hooks/use-toast';
import { Loader2, User } from 'lucide-react';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { Badge } from '@/components/ui/badge';
import React, { useState, useEffect } from 'react';

const profileSchema = z.object({
  displayName: z.string().min(2, 'Display name must be at least 2 characters.'),
  zone: z.string().optional(),
  expertise: z.string().optional(),
  skills: z.string().optional(),
});

type ProfileFormValues = z.infer<typeof profileSchema>;

export default function ProfilePage() {
  const { farmData, updateFarmData, loading: farmDataLoading } = useFarmData();
  const { user, loading: authLoading } = useAuth();
  const { toast } = useToast();
  const [isSubmitting, setIsSubmitting] = useState(false);

  const form = useForm<ProfileFormValues>({
    resolver: zodResolver(profileSchema),
    defaultValues: {
      displayName: '',
      zone: '',
      expertise: '',
      skills: '',
    },
  });

  useEffect(() => {
    if (farmData) {
      form.reset({
        displayName: farmData.displayName || user?.displayName || '',
        zone: farmData.zone || '',
        expertise: farmData.expertise || '',
        skills: Array.isArray(farmData.skills) ? farmData.skills.join(', ') : '',
      });
    }
  }, [farmData, user, form]);

  const onSubmit = (values: ProfileFormValues) => {
    setIsSubmitting(true);
    const skillsArray = values.skills ? values.skills.split(',').map(s => s.trim()).filter(Boolean) : [];
    updateFarmData({ ...values, skills: skillsArray });
    toast({ title: 'Profile Updated', description: 'Your profile has been successfully saved.' });
    setIsSubmitting(false);
  };
  
  const isLoading = farmDataLoading || authLoading;

  if (isLoading) {
    return (
      <div className="container mx-auto p-4 flex justify-center">
        <Loader2 className="h-8 w-8 animate-spin" />
      </div>
    );
  }
  
  const currentSkills = Array.isArray(farmData.skills) ? farmData.skills : [];

  const getInitials = () => {
    if (farmData.displayName) return farmData.displayName[0].toUpperCase();
    if (user?.displayName) return user.displayName[0].toUpperCase();
    if (user?.email) return user.email[0].toUpperCase();
    return <User />;
  }

  return (
    <div className="container mx-auto p-4 md:p-8">
      <Card className="max-w-4xl mx-auto">
        <CardHeader className="text-center">
          <div className="relative w-24 h-24 mx-auto mb-4">
            <Avatar className="w-24 h-24">
              <AvatarImage src={user?.photoURL || ''} />
              <AvatarFallback className="text-3xl">{getInitials()}</AvatarFallback>
            </Avatar>
            {/* Note: Profile picture editing is a future enhancement */}
          </div>
          <CardTitle className="text-3xl font-headline">{farmData.displayName || user?.displayName || 'Your Profile'}</CardTitle>
          <CardDescription>{farmData.expertise || 'Describe your expertise'}</CardDescription>
           {currentSkills.length > 0 && (
            <div className="flex flex-wrap justify-center gap-2 pt-2">
              {currentSkills.map((skill, index) => (
                <Badge key={index} variant="secondary">{skill}</Badge>
              ))}
            </div>
          )}
        </CardHeader>
        <CardContent>
          <Form {...form}>
            <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
              <FormField
                control={form.control}
                name="displayName"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Display Name</FormLabel>
                    <FormControl>
                      <Input placeholder="e.g., Jane Doe" {...field} />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
               <FormField
                control={form.control}
                name="zone"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Location / Zone</FormLabel>
                    <FormControl>
                      <Input placeholder="e.g., San Francisco, CA or 94107" {...field} />
                    </FormControl>
                    <FormDescription>Used for local weather & advice.</FormDescription>
                    <FormMessage />
                  </FormItem>
                )}
              />
              <FormField
                control={form.control}
                name="expertise"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Expertise / Bio</FormLabel>
                    <FormControl>
                      <Textarea placeholder="e.g., Specialist in organic viticulture and soil health." {...field} />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              <FormField
                control={form.control}
                name="skills"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Skills</FormLabel>
                    <FormControl>
                      <Input placeholder="e.g., Drip Irrigation, Cover Cropping, Pest Management" {...field} />
                    </FormControl>
                     <FormDescription>Separate skills with a comma.</FormDescription>
                    <FormMessage />
                  </FormItem>
                )}
              />
              <Button type="submit" className="w-full" disabled={isSubmitting}>
                {isSubmitting ? <Loader2 className="animate-spin" /> : 'Save Profile'}
              </Button>
            </form>
          </Form>
        </CardContent>
      </Card>
    </div>
  );
}
