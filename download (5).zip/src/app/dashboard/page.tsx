'use client';

import { useFarmData } from '@/hooks/use-farm-data';
import { GetStartedForm } from '@/components/dashboard/get-started-form';
import { CommercialDashboard } from '@/components/dashboard/commercial-dashboard';
import { HobbyistDashboard } from '@/components/dashboard/hobbyist-dashboard';

export default function DashboardPage() {
  const { farmData, isDataEntered } = useFarmData();

  if (!isDataEntered) {
    return <GetStartedForm />;
  }
  
  if (farmData.userType === 'hobbyist') {
    return <HobbyistDashboard />;
  }

  // Default to commercial dashboard
  return <CommercialDashboard />;
}
