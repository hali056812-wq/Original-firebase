'use client';

import { useState, useEffect, useRef } from 'react';
import { useFirestore, useCollection, useMemoFirebase, errorEmitter, FirestorePermissionError } from '@/firebase';
import { useAuth } from '@/hooks/use-auth';
import { useFarmData } from '@/hooks/use-farm-data';
import { collection, query, orderBy, addDoc, serverTimestamp, limit, doc, getDoc, setDoc } from 'firebase/firestore';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { Loader2, Send, User } from 'lucide-react';
import { ScrollArea } from '@/components/ui/scroll-area';
import { cn } from '@/lib/utils';
import { useToast } from '@/hooks/use-toast';

interface Message {
  id: string;
  content: string;
  createdAt: any;
  userId: string;
  userDisplayName?: string;
  userPhotoURL?: string;
}

const GLOBAL_COMMUNITY_ID = "global_chat";

export default function CommunityPage() {
  const firestore = useFirestore();
  const { user } = useAuth();
  const { farmData } = useFarmData();
  const { toast } = useToast();
  
  const [input, setInput] = useState('');
  const [loading, setLoading] = useState(false);
  const scrollAreaRef = useRef<HTMLDivElement>(null);

  // Ensure global community exists
  useEffect(() => {
    if (!firestore) return;
    const communityRef = doc(firestore, 'communities', GLOBAL_COMMUNITY_ID);
    const setupCommunity = async () => {
        const communitySnap = await getDoc(communityRef);
        if (!communitySnap.exists()) {
            const communityData = {
                name: 'Global Community Chat',
                description: 'A place for all farmers to connect and share knowledge.'
            };
            setDoc(communityRef, communityData).catch(async (serverError) => {
                const permissionError = new FirestorePermissionError({
                    path: communityRef.path,
                    operation: 'create',
                    requestResourceData: communityData,
                });
                errorEmitter.emit('permission-error', permissionError);
            });
        }
    };
    setupCommunity();
  }, [firestore]);


  const messagesCollectionRef = useMemoFirebase(() => {
    if (!firestore) return null;
    return query(
      collection(firestore, `communities/${GLOBAL_COMMUNITY_ID}/messages`),
      orderBy('createdAt', 'asc'),
      limit(50)
    );
  }, [firestore]);

  const { data: messages, isLoading: messagesLoading } = useCollection<Message>(messagesCollectionRef);

  useEffect(() => {
    if (scrollAreaRef.current) {
        const viewport = scrollAreaRef.current.querySelector('div[data-radix-scroll-area-viewport]');
        if (viewport) {
            viewport.scrollTop = viewport.scrollHeight;
        }
    }
  }, [messages]);

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setInput(e.target.value);
  };

  const handleSubmit = async (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    if (!input.trim() || !user || !firestore) return;

    setLoading(true);
    
    const messagesRef = collection(firestore, `communities/${GLOBAL_COMMUNITY_ID}/messages`);
    const messageData = {
        content: input,
        createdAt: serverTimestamp(),
        userId: user.uid,
        userDisplayName: farmData.displayName || user.displayName || user.email,
        userPhotoURL: user.photoURL
    };

    addDoc(messagesRef, messageData).then(() => {
        setInput('');
    }).catch(async (serverError) => {
        const permissionError = new FirestorePermissionError({
            path: messagesRef.path,
            operation: 'create',
            requestResourceData: messageData,
        });
        errorEmitter.emit('permission-error', permissionError);
        toast({
            variant: "destructive",
            title: "Failed to send message",
            description: "You may not have permission to post messages."
        });
    }).finally(() => {
        setLoading(false);
    });
  };
  
  const getSenderInitials = (message: Message) => {
    if (message.userDisplayName) return message.userDisplayName[0].toUpperCase();
    return <User />;
  }
  
  const getCurrentUserInitials = () => {
    if (farmData.displayName) return farmData.displayName[0].toUpperCase();
    if (user?.displayName) return user.displayName[0].toUpperCase();
    if (user?.email) return user.email[0].toUpperCase();
    return <User />;
  }

  return (
    <div className="container mx-auto p-4 md:p-8 h-[calc(100vh-10rem)]">
      <Card className="h-full flex flex-col">
        <CardHeader>
          <CardTitle className="text-3xl font-headline">Community Chat</CardTitle>
          <CardDescription>Welcome to the global chat. Share your thoughts and connect with other farmers.</CardDescription>
        </CardHeader>
        <CardContent className="flex-grow flex flex-col min-h-0">
          <ScrollArea className="flex-grow pr-4 -mr-4" ref={scrollAreaRef}>
            <div className="space-y-4">
              {messagesLoading && (
                 <div className="flex justify-center items-center h-full">
                    <Loader2 className="h-8 w-8 animate-spin text-muted-foreground" />
                 </div>
              )}
              {messages?.map((message) => (
                <div key={message.id} className={cn('flex items-start gap-3', message.userId === user?.uid ? 'justify-end' : 'justify-start')}>
                  {message.userId !== user?.uid && (
                    <Avatar className="w-8 h-8">
                       <AvatarImage src={message.userPhotoURL || ''} />
                       <AvatarFallback>
                           {getSenderInitials(message)}
                       </AvatarFallback>
                    </Avatar>
                  )}
                  <div className={cn(
                      'p-3 rounded-lg max-w-sm md:max-w-md lg:max-w-lg shadow-sm', 
                      message.userId === user?.uid ? 'bg-primary text-primary-foreground' : 'bg-card'
                    )}>
                    <p className="text-xs font-bold mb-1">{message.userId === user?.uid ? 'You' : message.userDisplayName}</p>
                    <p className="text-sm">{message.content}</p>
                  </div>
                  {message.userId === user?.uid && (
                      <Avatar className="w-8 h-8">
                          <AvatarImage src={user.photoURL || ''} />
                          <AvatarFallback>
                              {getCurrentUserInitials()}
                          </AvatarFallback>
                      </Avatar>
                  )}
                </div>
              ))}
            </div>
          </ScrollArea>
          <div className="mt-4 pt-4 border-t">
              <form onSubmit={handleSubmit} className="flex gap-2">
                  <Input
                      value={input}
                      onChange={handleInputChange}
                      placeholder="Type your message..."
                      disabled={loading || !user}
                      autoComplete="off"
                  />
                  <Button type="submit" disabled={loading || !input.trim() || !user}>
                      {loading ? <Loader2 className="h-4 w-4 animate-spin" /> : <Send className="h-4 w-4" />}
                  </Button>
              </form>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
