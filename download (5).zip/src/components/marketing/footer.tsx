'use client';

export function MarketingFooter() {
  return (
    <footer className="py-6 border-t bg-background/95">
      <div className="container text-center text-sm text-muted-foreground">
        © Smart Farm Assistant – Empowering Farmers with AI
      </div>
    </footer>
  );
}
