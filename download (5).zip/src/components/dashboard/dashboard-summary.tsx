'use client';

import Link from 'next/link';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { formatCurrency } from '@/lib/utils';
import { DollarSign, Tractor, TrendingUp, PlusCircle } from 'lucide-react';
import { useFarmData } from '@/hooks/use-farm-data';

export function DashboardSummary() {
    const { farmCalculations, farmData, loading } = useFarmData();

  if (loading) {
    return (
        <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
            {Array.from({ length: 4 }).map((_, index) => (
                <Card key={index}>
                    <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                       <div className="h-4 bg-muted rounded w-3/4" />
                    </CardHeader>
                    <CardContent>
                        <div className="h-8 bg-muted rounded w-1/2 mb-2" />
                        <div className="h-3 bg-muted rounded w-full" />
                    </CardContent>
                </Card>
            ))}
        </div>
    );
  }
  
  const profitMargin = farmCalculations.totalSales > 0 ? (farmCalculations.totalProfit / farmCalculations.totalSales) * 100 : 0;

  const summaryData = [
    {
      title: 'Total Revenue',
      value: formatCurrency(farmCalculations.totalSales),
      icon: DollarSign,
      change: 'All sales from your farm',
    },
    {
      title: 'Total Profit',
      value: formatCurrency(farmCalculations.totalProfit),
      icon: TrendingUp,
      change: `${profitMargin.toFixed(1)}% margin`,
    },
    {
      title: 'Total Fields',
      value: farmData.fields?.length || 0,
      icon: Tractor,
      change: 'Number of tracked fields',
    },
  ];

  return (
    <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
      {summaryData.map((item, index) => (
        <Card key={index}>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">{item.title}</CardTitle>
            <item.icon className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{item.value}</div>
            <p className="text-xs text-muted-foreground">{item.change}</p>
          </CardContent>
        </Card>
      ))}
       <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium">Quick Actions</CardTitle>
          </CardHeader>
          <CardContent className="flex flex-col gap-2">
             <Link href="/dashboard?tab=farm-management&transaction=sale">
                <Button className="w-full">
                    <PlusCircle /> Add Sale
                </Button>
            </Link>
             <Link href="/dashboard?tab=farm-management&transaction=cost">
                <Button className="w-full" variant="secondary">
                     <PlusCircle /> Add Cost
                </Button>
            </Link>
          </CardContent>
        </Card>
    </div>
  );
}
