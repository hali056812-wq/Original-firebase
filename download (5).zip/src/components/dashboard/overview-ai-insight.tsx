'use client';

import { useState, useEffect, useCallback, useMemo, useRef } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle, CardFooter } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { useFarmData } from '@/hooks/use-farm-data';
import { generateAiInsight } from '@/ai/flows/generate-ai-insight';
import { Loader2, Lightbulb, Tractor, BarChart, History, RefreshCw, Activity, Scan, LandPlot } from 'lucide-react';
import { formatDistanceToNow } from '@/lib/utils';
import { isThisWeek } from 'date-fns';
import { useToast } from '@/hooks/use-toast';
import { cn } from '@/lib/utils';
import { Skeleton } from '@/components/ui/skeleton';
import { useUser } from '@/firebase';

function getSeason(date: Date) {
    const month = date.getMonth();
    if (month >= 2 && month <= 4) return 'Spring';
    if (month >= 5 && month <= 7) return 'Summer';
    if (month >= 8 && month <= 10) return 'Autumn';
    return 'Winter';
}

export function OverviewAiInsight() {
    const { farmData, farmCalculations, loading: farmDataLoading } = useFarmData();
    const { user } = useUser();
    const [insight, setInsight] = useState<string | null>(null);
    const [loading, setLoading] = useState(true);
    const { toast } = useToast();
    const hasFetched = useRef(false);
    const refreshTimeout = useRef<NodeJS.Timeout | null>(null);
    const lastRefreshTime = useRef<Date | null>(null);

    const recentActivityCounts = useMemo(() => {
        const aWeekAgo = new Date();
        aWeekAgo.setDate(aWeekAgo.getDate() - 7);

        const recentTransactions = (farmData.financialEntries || []).filter(entry => {
            const entryDate = new Date(entry.date);
            return entryDate > aWeekAgo;
        }).length;

        const completedTasks = (farmData.tasks || []).filter(t => {
             const taskDate = new Date(t.dueDate);
             return t.status === 'completed' && taskDate > aWeekAgo;
        }).length;

        return { recentTransactions, completedTasks };
    }, [farmData.financialEntries, farmData.tasks]);

    const currentSeason = useMemo(() => getSeason(new Date()), []);

    const fetchInsight = useCallback(async () => {
        setLoading(true);
        try {
            const profitStatus = farmCalculations.totalProfit > 0 ? 'positive' : farmCalculations.totalProfit < 0 ? 'negative' : 'neutral';
            
            const pendingTasks = (farmData.tasks || []).filter(t => t.status === 'pending').length;

            const result = await generateAiInsight({
                userType: farmData.userType,
                crops: farmData.fields?.map(f => f.crop) || [],
                location: farmData.zone,
                profitStatus,
                season: currentSeason,
                recentTransactionsCount: recentActivityCounts.recentTransactions,
                tasks: { pending: pendingTasks, completed: recentActivityCounts.completedTasks },
            });

            if (result.insight) {
                setInsight(result.insight);
            }

        } catch (error) {
            console.error("Failed to fetch AI insight:", error);
            if (!insight) {
                 setInsight("Could not load an insight right now. Please try again later.");
            }
        }
        setLoading(false);
        lastRefreshTime.current = new Date();
    }, [farmData, farmCalculations, currentSeason, recentActivityCounts, insight]);

    useEffect(() => {
        if (user && !farmDataLoading) {
            if (hasFetched.current) return;
            hasFetched.current = true;
            fetchInsight();
        }
    }, [user, farmDataLoading, fetchInsight]);
    
    useEffect(() => {
        return () => {
            if (refreshTimeout.current) {
                clearTimeout(refreshTimeout.current);
            }
        }
    }, []);

    const handleRefresh = () => {
        if (loading) return;
        
        if (lastRefreshTime.current && new Date().getTime() - lastRefreshTime.current.getTime() < 3000) {
            toast({
                title: "Please wait",
                description: "You can request a new insight in a few seconds.",
            });
            return;
        }
        fetchInsight();
    };
    
    const handleGoToManagement = () => {
        const element = document.getElementById('farm-management-tabs');
        element?.scrollIntoView({ behavior: 'smooth', block: 'start' });
    }

    const transactionsThisMonth = (farmData.financialEntries || []).filter(entry => 
        new Date(entry.date).getMonth() === new Date().getMonth() &&
        new Date(entry.date).getFullYear() === new Date().getFullYear()
    ).length;

    const activitiesThisWeek = (farmData.financialEntries?.length || 0) + (farmData.tasks?.filter(t => t.status === 'completed' && isThisWeek(new Date(t.dueDate))).length || 0);

    const isCommercial = farmData.userType === 'commercial';

    return (
        <Card className="h-full flex flex-col">
            <CardHeader className="flex-row items-start justify-between">
                <div>
                    <CardTitle className="font-headline flex items-center gap-2">
                        <Lightbulb className="text-primary"/>
                        Overview & AI Insight
                    </CardTitle>
                </div>
                <Button variant="ghost" size="icon" onClick={handleRefresh} disabled={loading}>
                    <RefreshCw className={cn("w-5 h-5", loading && "animate-spin")} />
                </Button>
            </CardHeader>
            <CardContent className="flex-grow space-y-4">
                <div className="p-4 bg-muted rounded-lg h-20 flex items-center justify-center relative">
                     {loading && !insight ? (
                        <div className="flex items-center text-muted-foreground">
                            <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                            <span className="italic">Generating your AI insight...</span>
                        </div>
                     ) :
                     (
                        <div className="relative w-full">
                             <p className={cn("text-center italic text-sm md:text-base px-6", loading && "opacity-50")}>
                                "{insight || 'Loading your daily insight...'}"
                             </p>
                             {loading && <Skeleton className="absolute inset-0 w-full h-full" />}
                        </div>
                     )}
                </div>
                {isCommercial ? (
                    <div className="grid grid-cols-3 gap-4 text-center">
                        <div className="p-2 bg-background rounded-lg">
                            <Tractor className="mx-auto mb-1 text-muted-foreground"/>
                            <p className="text-xl font-bold">{farmData.fields?.length || 0}</p>
                            <p className="text-xs text-muted-foreground">Fields Drawn</p>
                        </div>
                        <div className="p-2 bg-background rounded-lg">
                            <BarChart className="mx-auto mb-1 text-muted-foreground"/>
                            <p className="text-xl font-bold">{transactionsThisMonth}</p>
                            <p className="text-xs text-muted-foreground">Transactions (Month)</p>
                        </div>
                        <div className="p-2 bg-background rounded-lg">
                            <History className="mx-auto mb-1 text-muted-foreground"/>
                            <p className="text-xl font-bold capitalize">{formatDistanceToNow(farmData.lastActivity)}</p>
                            <p className="text-xs text-muted-foreground">Last Activity</p>
                        </div>
                    </div>
                ) : (
                     <div className="grid grid-cols-3 gap-4 text-center">
                        <div className="p-2 bg-background rounded-lg">
                            <LandPlot className="mx-auto mb-1 text-muted-foreground"/>
                            <p className="text-xl font-bold">{farmData.fields?.length || 0}</p>
                            <p className="text-xs text-muted-foreground">Plots</p>
                        </div>
                        <div className="p-2 bg-background rounded-lg">
                            <Activity className="mx-auto mb-1 text-muted-foreground"/>
                            <p className="text-xl font-bold">{activitiesThisWeek}</p>
                            <p className="text-xs text-muted-foreground">This Week's Activity</p>
                        </div>
                        <div className="p-2 bg-background rounded-lg">
                            <Scan className="mx-auto mb-1 text-muted-foreground"/>
                            <p className="text-xl font-bold capitalize">{formatDistanceToNow(farmData.lastActivity)}</p>
                            <p className="text-xs text-muted-foreground">Last Scan</p>
                        </div>
                    </div>
                )}
            </CardContent>
            {isCommercial && (
                <CardFooter className="flex justify-end gap-2 text-sm">
                    <Button variant="outline" onClick={handleGoToManagement}>Go to management</Button>
                </CardFooter>
            )}
        </Card>
    );
}
