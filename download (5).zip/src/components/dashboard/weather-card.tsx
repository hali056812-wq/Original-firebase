'use client';

import { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { getWeatherForecast, type GetWeatherForecastOutput } from '@/ai/flows/get-weather-forecast';
import { Loader2, Thermometer, Wind, Droplets, Cloud, Sun, CloudSun, CloudRain, CloudSnow, AlertTriangle, LandPlot } from 'lucide-react';
import { useFarmData } from '@/hooks/use-farm-data';
import { Alert, AlertTitle, AlertDescription } from '../ui/alert';
import { Button } from '../ui/button';
import Link from 'next/link';

const weatherIcons: { [key: string]: React.ElementType } = {
  'sunny': Sun,
  'clear': Sun,
  'partly cloudy': CloudSun,
  'cloudy': Cloud,
  'clouds': Cloud,
  'rainy': CloudRain,
  'rain': CloudRain,
  'snowy': CloudSnow,
  'snow': CloudSnow,
  'storm': AlertTriangle,
  'default': Cloud,
};

const getWeatherIcon = (conditions: string) => {
  const lowerConditions = conditions.toLowerCase();
  for (const key in weatherIcons) {
    if (lowerConditions.includes(key)) {
      return weatherIcons[key];
    }
  }
  return weatherIcons.default;
};

export function WeatherCard() {
  const { farmData, isDataEntered } = useFarmData();
  const [forecastData, setForecastData] = useState<GetWeatherForecastOutput | null>(null);
  const [loading, setLoading] = useState(false);
  
  const location = farmData.zone;
  const forecast = forecastData?.forecast;
  const error = forecastData?.error;

  useEffect(() => {
    async function fetchWeather() {
      if (!isDataEntered || !location) {
        setForecastData(null);
        return;
      };

      setLoading(true);
      setForecastData(null);
      try {
        const result = await getWeatherForecast({ location });
        setForecastData(result);
      } catch (e) {
        console.error(e);
        setForecastData({ forecast: null, error: 'Failed to get weather forecast. Please try again later.' });
      }
      setLoading(false);
    }

    fetchWeather();
  }, [location, isDataEntered]);

  if (!isDataEntered) {
    return null;
  }
  
  const WeatherIcon = forecast ? getWeatherIcon(forecast.conditions) : null;

  return (
    <Card className="mt-4">
        <CardHeader>
            <CardTitle className="font-headline">Local Weather</CardTitle>
            {location && <CardDescription>Current conditions for {location}</CardDescription>}
        </CardHeader>
        <CardContent>
            {!location ? (
                <div className="text-center text-muted-foreground p-8">
                    <LandPlot className="mx-auto h-12 w-12 mb-4" />
                    <p className="font-bold">Location Not Set</p>
                    <p className="mb-4">Add a location to your profile to see local weather.</p>
                    <Link href="/dashboard/profile">
                        <Button>Add Location</Button>
                    </Link>
                </div>
            ) : loading ? (
                <div className="h-24 flex items-center justify-center">
                    <Loader2 className="h-8 w-8 animate-spin text-muted-foreground" />
                </div>
            ) : error ? (
                <Alert variant="destructive">
                    <AlertTriangle className="h-4 w-4" />
                    <AlertTitle>Weather Data Unavailable</AlertTitle>
                    <AlertDescription>{error}</AlertDescription>
                </Alert>
            ) : forecast && (
                <>
                 {forecast.alerts && forecast.alerts.length > 0 && (
                    <div className="mb-4 space-y-2">
                        {forecast.alerts.map((alert, index) => (
                        <Alert key={index} variant="destructive">
                            <AlertTriangle className="h-4 w-4" />
                            <AlertTitle>{alert.type} - {alert.severity}</AlertTitle>
                            <AlertDescription>{alert.description}</AlertDescription>
                        </Alert>
                        ))}
                    </div>
                    )}
                <div className="grid grid-cols-2 md:grid-cols-4 gap-4 text-center">
                    <div className="flex flex-col items-center justify-center gap-2 p-4 bg-muted rounded-lg">
                        {WeatherIcon && <WeatherIcon className="w-8 h-8 text-primary" />}
                        <p className="font-semibold">Conditions</p>
                        <p className="text-xl font-bold">{Math.round(forecast.temperatureFahrenheit)}°F ({forecast.conditions})</p>
                    </div>
                     <div className="flex flex-col items-center justify-center gap-2 p-4 bg-muted rounded-lg">
                        <Thermometer className="w-8 h-8 text-primary" />
                        <p className="font-semibold">Temperature</p>
                        <p className="text-xl font-bold">{Math.round(forecast.temperature)}°C</p>
                    </div>
                    <div className="flex flex-col items-center justify-center gap-2 p-4 bg-muted rounded-lg">
                        <Droplets className="w-8 h-8 text-primary" />
                        <p className="font-semibold">Humidity</p>
                        <p className="text-xl font-bold">{forecast.humidity}%</p>
                    </div>
                    <div className="flex flex-col items-center justify-center gap-2 p-4 bg-muted rounded-lg">
                        <Wind className="w-8 h-8 text-primary" />
                        <p className="font-semibold">Wind Speed</p>
                        <p className="text-xl font-bold">{Math.round(forecast.windSpeed)} km/h</p>
                    </div>
                </div>
                </>
            )}
        </CardContent>
    </Card>
  );
}
