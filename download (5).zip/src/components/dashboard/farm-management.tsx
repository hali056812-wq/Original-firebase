'use client';

import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { FieldTracker } from './field-tracker';
import { BusinessTools } from './business-tools';
import { Briefcase, Tractor, Loader2 } from 'lucide-react';
import { useFarmData } from '@/hooks/use-farm-data';
import { FarmSetupForm } from './farm-setup-form';

export function FarmManagement() {
  const { farmData, loading } = useFarmData();

  if (loading) {
    return (
      <div className="flex items-center justify-center h-64">
        <Loader2 className="w-8 h-8 animate-spin text-muted-foreground" />
      </div>
    );
  }

  if (!farmData.isFarmSetupComplete) {
    return <FarmSetupForm />;
  }

  return (
    <Tabs defaultValue="business" className="w-full">
      <TabsList className="grid w-full grid-cols-2">
        <TabsTrigger value="business">
          <Briefcase className="w-4 h-4 mr-2" />
          Business
        </TabsTrigger>
        {farmData.trackingStyle === 'by_field' && (
           <TabsTrigger value="tracking">
              <Tractor className="w-4 h-4 mr-2" />
              Fields
            </TabsTrigger>
        )}
      </TabsList>
      <TabsContent value="business" className="mt-6">
        <BusinessTools />
      </TabsContent>
      {farmData.trackingStyle === 'by_field' && (
        <TabsContent value="tracking" className="mt-6">
            <FieldTracker />
        </TabsContent>
      )}
    </Tabs>
  );
}
