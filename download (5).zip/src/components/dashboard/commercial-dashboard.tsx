'use client';

import { useState, useEffect } from 'react';
import Link from 'next/link';
import { useSearchParams } from 'next/navigation';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { DashboardSummary } from '@/components/dashboard/dashboard-summary';
import { CropRecommendations } from '@/components/dashboard/crop-recommendations';
import { AiAssistant } from '@/components/dashboard/ai-assistant';
import { PlantScanner } from '@/components/dashboard/plant-scanner';
import { FarmManagement } from '@/components/dashboard/farm-management';
import { Leaf, Bot, Scan, LandPlot, Briefcase, Users } from 'lucide-react';
import { WeatherCard } from '@/components/dashboard/weather-card';
import { Button } from '@/components/ui/button';
import { useFarmData } from '@/hooks/use-farm-data';
import { OverviewAiInsight } from './overview-ai-insight';
import { UpcomingTasks } from './upcoming-tasks';

export function CommercialDashboard() {
  const searchParams = useSearchParams();
  const initialTab = searchParams.get('tab') || 'recommendations';
  const [activeTab, setActiveTab] = useState(initialTab);
  const { updateFarmData } = useFarmData();

  useEffect(() => {
    const tab = searchParams.get('tab');
    if (tab) {
      setActiveTab(tab);

      // Scroll to the form if a transaction is specified
      if (tab === 'farm-management' && searchParams.get('transaction')) {
        setTimeout(() => {
            const formElement = document.getElementById('add-transaction-form');
            formElement?.scrollIntoView({ behavior: 'smooth', block: 'start' });
        }, 100); // Small delay to ensure the tab content is rendered
      }
    }
  }, [searchParams]);

  const handleSwitchToHobbyist = () => {
    updateFarmData({ userType: 'hobbyist' });
  };

  return (
    <div className="container mx-auto px-4 py-8 md:px-6 md:py-12">
      <div className="flex flex-col md:flex-row md:items-center md:justify-between mb-8">
        <h1 className="text-3xl font-bold tracking-tighter font-headline text-center md:text-left">
          Your Farm Dashboard
        </h1>
        <div className="mt-4 md:mt-0 flex items-center justify-center gap-2">
            <Button variant="outline" onClick={handleSwitchToHobbyist}>
                <Briefcase className="mr-2 h-4 w-4" />
                Switch to Hobbyist View
            </Button>
             <Link href="/dashboard/community">
                <Button>
                    <Users className="mr-2 h-4 w-4" />
                    Join the Community
                </Button>
            </Link>
        </div>
      </div>

      <div className="grid lg:grid-cols-3 gap-4 mb-4">
          <div className="lg:col-span-2">
            <OverviewAiInsight />
          </div>
          <div className="lg:col-span-1">
            <UpcomingTasks />
          </div>
      </div>

      <DashboardSummary />
      <WeatherCard />
      <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full mt-12" id="farm-management-tabs">
        <TabsList className="grid w-full grid-cols-2 md:grid-cols-4 h-auto">
          <TabsTrigger value="recommendations" className="py-2">
            <Leaf className="w-4 h-4 mr-2" /> Crop Recommendations
          </TabsTrigger>
          <TabsTrigger value="assistant" className="py-2">
            <Bot className="w-4 h-4 mr-2" /> AI Assistant
          </TabsTrigger>
          <TabsTrigger value="scanner" className="py-2">
            <Scan className="w-4 h-4 mr-2" /> Plant Scanner
          </TabsTrigger>
          <TabsTrigger value="farm-management" className="py-2">
            <LandPlot className="w-4 h-4 mr-2" /> Farm Management
          </TabsTrigger>
        </TabsList>
        <TabsContent value="recommendations" className="mt-6">
          <CropRecommendations />
        </TabsContent>
        <TabsContent value="assistant" className="mt-6">
          <AiAssistant />
        </TabsContent>
        <TabsContent value="scanner" className="mt-6">
          <PlantScanner />
        </TabsContent>
        <TabsContent value="farm-management" className="mt-6">
          <FarmManagement />
        </TabsContent>
      </Tabs>
    </div>
  );
}
