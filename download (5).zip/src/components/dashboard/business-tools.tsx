'use client';

import { useState, useEffect, useCallback } from 'react';
import { useForm } from 'react-hook-form';
import { useSearchParams } from 'next/navigation';
import { zodResolver } from '@hookform/resolvers/zod';
import { z } from 'zod';
import { useFarmData, type Field } from '@/hooks/use-farm-data';
import { formatCurrency, cn } from '@/lib/utils';
import { Card, CardContent, CardDescription, CardHeader, CardTitle, CardFooter } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from '@/components/ui/form';
import { Popover, PopoverContent, PopoverTrigger } from '@/components/ui/popover';
import { Calendar } from '@/components/ui/calendar';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { CalendarIcon, PlusCircle, ArrowDown, ArrowUp, BarChart, Trash2, DollarSign, Sparkles, Loader2, LandPlot } from 'lucide-react';
import { format, isToday } from 'date-fns';
import { FinancialChart } from './financial-chart';
import { summarizeFinancialPerformance } from '@/ai/flows/summarize-financial-performance';
import { Alert, AlertDescription, AlertTitle } from '../ui/alert';
import { useToast } from '@/hooks/use-toast';
import { Skeleton } from '@/components/ui/skeleton';
import { useUser } from '@/firebase';

interface CachedSummary {
    summary: string;
    date: string; // ISO string date
    transactionCount: number;
}

const financialEntrySchema = z.object({
  type: z.enum(['sale', 'cost']),
  amount: z.coerce.number().positive('Amount must be positive'),
  description: z.string().min(1, 'Description is required'),
  date: z.date({ required_error: 'Date is required' }),
  fieldId: z.string().optional(),
});

type FinancialEntryFormValues = z.infer<typeof financialEntrySchema>;

function AiSummary() {
    const { farmCalculations, farmData } = useFarmData();
    const { user } = useUser();
    const [summary, setSummary] = useState<string | null>(null);
    const [loading, setLoading] = useState(false);
    const [error, setError] = useState<string | null>(null);

    const getSummary = useCallback(async () => {
        if (farmData.financialEntries.length === 0) {
            setSummary("Add your first sale or cost to get an AI-powered summary of your farm's performance.");
            return;
        }
        
        setLoading(true);
        setError(null);

        const today = new Date().toISOString().split('T')[0];
        const currentTransactionCount = farmData.financialEntries.length;
        const cacheKey = `financialSummary_${user?.uid}`;
        const cachedItem = localStorage.getItem(cacheKey);
        let cachedData: CachedSummary | null = null;
        
        if (cachedItem) {
            try {
                cachedData = JSON.parse(cachedItem);
            } catch {
                cachedData = null;
            }
        }

        // Use cache if it's from today and the number of transactions hasn't changed.
        if (cachedData && cachedData.date === today && cachedData.transactionCount === currentTransactionCount) {
            setSummary(cachedData.summary);
            setLoading(false);
            return;
        }

        // If cache is stale or invalid, fetch a new summary.
        try {
            const fieldBreakdown = Object.entries(farmCalculations.fieldFinancials).map(([fieldId, financials]) => {
                const field = farmData.fields.find(f => f.id === fieldId);
                return {
                    fieldName: field?.name || 'Unknown Field',
                    ...financials
                }
            });

            const result = await summarizeFinancialPerformance({
                totalSales: farmCalculations.totalSales,
                totalCosts: farmCalculations.totalCosts,
                totalProfit: farmCalculations.totalProfit,
                fieldBreakdown: fieldBreakdown,
            });
            
            if (result.summary) {
                setSummary(result.summary);
                const newCachedData: CachedSummary = {
                    summary: result.summary,
                    date: today,
                    transactionCount: currentTransactionCount,
                };
                // Update the cache.
                localStorage.setItem(cacheKey, JSON.stringify(newCachedData));
            }

        } catch (e) {
            console.error(e);
            // If fetching fails but we have old cached data, show it as a fallback.
            if (cachedData) {
                setSummary(cachedData.summary);
            } else {
                setError("Could not generate AI summary at this time.");
            }
        }
        setLoading(false);
    }, [farmCalculations, farmData.financialEntries.length, farmData.fields, user?.uid]);

    useEffect(() => {
        if (user) {
            getSummary();
        }
    }, [getSummary, user]);

    return (
        <Card>
            <CardHeader>
                <CardTitle className="font-headline flex items-center gap-2">
                    <Sparkles className="w-5 h-5 text-primary"/>
                    AI Financial Summary
                </CardTitle>
            </CardHeader>
            <CardContent>
                {loading && !summary ? (
                     <div className="space-y-2">
                        <Skeleton className="h-4 w-full" />
                        <Skeleton className="h-4 w-full" />
                        <Skeleton className="h-4 w-3/4" />
                     </div>
                ) : error && !summary ? (
                    <Alert variant="destructive">
                        <AlertTitle>Error</AlertTitle>
                        <AlertDescription>{error}</AlertDescription>
                    </Alert>
                ) : summary && (
                    <div className="relative">
                        <p className={cn("text-sm", loading && "opacity-50")}>{summary}</p>
                        {loading && <Skeleton className="absolute inset-0 w-full h-full" />}
                    </div>
                )}
            </CardContent>
        </Card>
    );
}


function FinancialSummaryCard({ title, sales, costs, profit }: { title: string; sales: number; costs: number; profit: number }) {
    return (
        <Card>
            <CardHeader>
                <CardTitle className="text-xl font-headline">{title}</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
                <div className="flex justify-between items-center">
                    <span className="text-muted-foreground">Total Sales</span>
                    <span className="font-bold text-green-600">{formatCurrency(sales)}</span>
                </div>
                <div className="flex justify-between items-center">
                    <span className="text-muted-foreground">Total Costs</span>
                    <span className="font-bold text-red-600">{formatCurrency(costs)}</span>
                </div>
                <div className="flex justify-between items-center border-t pt-4">
                    <span className="font-bold">Profit</span>
                    <span className={cn("font-bold text-2xl", profit >= 0 ? 'text-foreground' : 'text-red-600')}>{formatCurrency(profit)}</span>
                </div>
            </CardContent>
        </Card>
    )
}

function EnableFieldTrackingCard() {
    const { updateFarmData } = useFarmData();
    const { toast } = useToast();

    const handleEnable = () => {
        updateFarmData({ trackingStyle: 'by_field' });
        toast({
            title: "Field Tracking Enabled",
            description: "You can now add fields and track their individual performance."
        })
    }

    return (
        <Card className="bg-muted/50 border-dashed">
            <CardHeader className="flex-row items-center gap-4">
                 <LandPlot className="w-8 h-8 text-primary"/>
                 <div>
                    <CardTitle className="text-lg font-headline">Want more detail?</CardTitle>
                    <CardDescription>Enable field-by-field tracking to manage profits for individual plots.</CardDescription>
                 </div>
            </CardHeader>
            <CardFooter>
                <Button onClick={handleEnable}>Enable Field Tracking</Button>
            </CardFooter>
        </Card>
    )
}

export function BusinessTools() {
  const { farmData, farmCalculations, addFinancialEntry, deleteFinancialEntry } = useFarmData();
  const searchParams = useSearchParams();
  const [isSubmitting, setIsSubmitting] = useState(false);
  const { fields = [], financialEntries = [], trackingStyle } = farmData;
  const hasFields = fields.length > 0;
  const hasFinancials = financialEntries.length > 0;

  const transactionType = searchParams.get('transaction');

  const form = useForm<FinancialEntryFormValues>({
    resolver: zodResolver(financialEntrySchema),
    defaultValues: {
      type: 'sale',
      amount: 0,
      description: '',
      fieldId: '__general__',
    },
  });

  useEffect(() => {
    if (transactionType === 'sale' || transactionType === 'cost') {
        form.setValue('type', transactionType);
    }
  }, [transactionType, form]);


  const onSubmit = (values: FinancialEntryFormValues) => {
    setIsSubmitting(true);
    addFinancialEntry({
        ...values,
        date: values.date.toISOString(),
        fieldId: values.fieldId === '__general__' ? null : values.fieldId,
    });
    form.reset({
        type: 'sale',
        amount: 0,
        description: '',
        date: undefined,
        fieldId: '__general__',
    });
    setIsSubmitting(false);
  };
  
  const recentEntries = (farmData.financialEntries || []).slice(-5).reverse();

  return (
    <div className="grid lg:grid-cols-3 gap-8 items-start">
        <div className="lg:col-span-1 space-y-6">
             <Card id="add-transaction-form">
                <CardHeader>
                    <CardTitle className="font-headline">Add Transaction</CardTitle>
                </CardHeader>
                <Form {...form}>
                    <form onSubmit={form.handleSubmit(onSubmit)}>
                        <CardContent className="space-y-4">
                            <FormField control={form.control} name="type" render={({ field }) => (
                                <FormItem><FormLabel>Type</FormLabel><Select onValueChange={field.onChange} value={field.value}><FormControl><SelectTrigger><SelectValue/></SelectTrigger></FormControl><SelectContent><SelectItem value="sale">Sale / Revenue</SelectItem><SelectItem value="cost">Cost / Expense</SelectItem></SelectContent></Select><FormMessage/></FormItem>
                            )}/>
                            <FormField control={form.control} name="description" render={({ field }) => (
                                <FormItem><FormLabel>Description</FormLabel><FormControl><Input placeholder="e.g., Sold 10 bushels of corn" {...field} /></FormControl><FormMessage/></FormItem>
                            )}/>
                            <FormField control={form.control} name="amount" render={({ field }) => (
                                <FormItem><FormLabel>Amount</FormLabel><FormControl><Input type="number" placeholder="100.00" {...field} /></FormControl><FormMessage/></FormItem>
                            )}/>
                            <FormField control={form.control} name="date" render={({ field }) => (
                                <FormItem className="flex flex-col"><FormLabel>Date</FormLabel><Popover><PopoverTrigger asChild><FormControl>
                                    <Button variant={"outline"} className={cn("pl-3 text-left font-normal", !field.value && "text-muted-foreground")}>
                                    {field.value ? format(field.value, "PPP") : <span>Pick a date</span>} <CalendarIcon className="ml-auto h-4 w-4 opacity-50" />
                                    </Button></FormControl></PopoverTrigger><PopoverContent className="w-auto p-0" align="start"><Calendar mode="single" selected={field.value} onSelect={field.onChange} /></PopoverContent></Popover><FormMessage/>
                                </FormItem>
                            )}/>
                             {trackingStyle === 'by_field' && hasFields && (
                                <FormField control={form.control} name="fieldId" render={({ field }) => (
                                <FormItem><FormLabel>Field (Optional)</FormLabel><Select onValueChange={field.onChange} defaultValue={field.value}><FormControl><SelectTrigger><SelectValue placeholder="Select a field"/></SelectTrigger></FormControl><SelectContent><SelectItem value="__general__">Whole Farm / General</SelectItem>{fields.map(f => (<SelectItem key={f.id} value={f.id}>{f.name}</SelectItem>))}</SelectContent></Select><FormMessage/></FormItem>
                            )}/>
                             )}
                        </CardContent>
                        <CardFooter>
                            <Button type="submit" disabled={isSubmitting} className="w-full">
                                <PlusCircle className="mr-2"/> Add Entry
                            </Button>
                        </CardFooter>
                    </form>
                </Form>
            </Card>
            <Card>
                <CardHeader><CardTitle className="font-headline">Recent Transactions</CardTitle></CardHeader>
                <CardContent>
                    <Table>
                        <TableBody>
                            {recentEntries.length > 0 ? recentEntries.map(entry => (
                                <TableRow key={entry.id}>
                                    <TableCell>
                                        {entry.type === 'sale' ? <ArrowUp className="h-5 w-5 text-green-500"/> : <ArrowDown className="h-5 w-5 text-red-500"/>}
                                    </TableCell>
                                    <TableCell>
                                        <p className="font-medium">{entry.description}</p>
                                        <p className="text-xs text-muted-foreground">{format(new Date(entry.date), "PPP")}</p>
                                    </TableCell>
                                    <TableCell className="text-right font-mono">{formatCurrency(entry.amount)}</TableCell>
                                    <TableCell><Button variant="ghost" size="icon" onClick={() => deleteFinancialEntry(entry.id)}><Trash2 className="h-4 w-4 text-destructive"/></Button></TableCell>
                                </TableRow>
                            )) : (
                                <TableRow><TableCell colSpan={4} className="text-center h-24">No transactions yet.</TableCell></TableRow>
                            )}
                        </TableBody>
                    </Table>
                </CardContent>
            </Card>
        </div>
        <div className="lg:col-span-2 space-y-6">
            <FinancialSummaryCard 
                title="Farm Overview" 
                sales={farmCalculations.totalSales}
                costs={farmCalculations.totalCosts}
                profit={farmCalculations.totalProfit}
            />
             <Card>
                <CardHeader>
                    <CardTitle className="font-headline">Financial Performance</CardTitle>
                    <CardDescription>Monthly sales and costs over the last 12 months.</CardDescription>
                </CardHeader>
                <CardContent>
                    <FinancialChart data={financialEntries} />
                </CardContent>
            </Card>
            {hasFinancials && <AiSummary />}
            {trackingStyle === 'by_field' && hasFields && (
                <Card>
                    <CardHeader>
                        <CardTitle className="font-headline">Field Breakdown</CardTitle>
                        <CardDescription>Profit and loss for each individual field.</CardDescription>
                    </CardHeader>
                    <CardContent className="space-y-4">
                        {fields.map(field => {
                            const financials = farmCalculations.fieldFinancials[field.id] || { sales: 0, costs: 0, profit: 0 };
                            return (
                                <div key={field.id} className="p-4 border rounded-lg">
                                    <h4 className="font-bold">{field.name}</h4>
                                    <div className="flex justify-between text-sm mt-2">
                                        <span>Sales: <span className="text-green-600">{formatCurrency(financials.sales)}</span></span>
                                        <span>Costs: <span className="text-red-600">{formatCurrency(financials.costs)}</span></span>
                                        <span className="font-bold">Profit: <span className={cn(financials.profit >= 0 ? 'text-foreground' : 'text-red-600')}>{formatCurrency(financials.profit)}</span></span>
                                    </div>
                                </div>
                            )
                        })}
                         <div className="p-4 border border-dashed rounded-lg">
                            <h4 className="font-bold">General / Unassigned</h4>
                             <div className="flex justify-between text-sm mt-2">
                                <span>Sales: <span className="text-green-600">{formatCurrency(farmCalculations.generalFinancials.sales)}</span></span>
                                <span>Costs: <span className="text-red-600">{formatCurrency(farmCalculations.generalFinancials.costs)}</span></span>
                                <span className="font-bold">Profit: <span className={cn(farmCalculations.generalFinancials.profit >= 0 ? 'text-foreground' : 'text-red-600')}>{formatCurrency(farmCalculations.generalFinancials.profit)}</span></span>
                            </div>
                        </div>
                    </CardContent>
                </Card>
            )}
            {trackingStyle === 'simple' && <EnableFieldTrackingCard />}
        </div>
    </div>
  );
}
