'use client';

import { useState, useRef, useEffect } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { answerFarmingQuestion } from '@/ai/flows/answer-farming-questions';
import { Avatar, AvatarFallback } from '../ui/avatar';
import { Bot, Loader2, Send, User as UserIcon, Trash2 } from 'lucide-react';
import { ScrollArea } from '../ui/scroll-area';
import { cn } from '@/lib/utils';
import { Alert, AlertTitle, AlertDescription } from '../ui/alert';

interface StructuredAnswer {
  summary: string;
  bulletPoints: string[];
  conclusion: string;
}

interface Message {
  role: 'user' | 'assistant';
  content: string | StructuredAnswer;
}

const SESSION_STORAGE_KEY = 'chatMessages';

export function AiAssistant() {
  const [messages, setMessages] = useState<Message[]>([]);
  const [input, setInput] = useState('');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const scrollAreaRef = useRef<HTMLDivElement>(null);

  // Load messages from sessionStorage on initial render
  useEffect(() => {
    try {
      const savedMessages = sessionStorage.getItem(SESSION_STORAGE_KEY);
      if (savedMessages) {
        setMessages(JSON.parse(savedMessages));
      }
    } catch (e) {
      console.error("Failed to parse messages from sessionStorage", e);
      sessionStorage.removeItem(SESSION_STORAGE_KEY);
    }
  }, []);

  // Save messages to sessionStorage whenever they change
  useEffect(() => {
    try {
      if (messages.length > 0) {
        sessionStorage.setItem(SESSION_STORAGE_KEY, JSON.stringify(messages));
      } else {
        sessionStorage.removeItem(SESSION_STORAGE_KEY);
      }
    } catch (e) {
      console.error("Failed to save messages to sessionStorage", e);
    }
  }, [messages]);


  useEffect(() => {
    if (scrollAreaRef.current) {
        const viewport = scrollAreaRef.current.querySelector('div[data-radix-scroll-area-viewport]');
        if (viewport) {
            viewport.scrollTop = viewport.scrollHeight;
        }
    }
  }, [messages, loading]);

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setInput(e.target.value);
  };

  const handleNewChat = () => {
    setMessages([]);
    setInput('');
    setError(null);
    sessionStorage.removeItem(SESSION_STORAGE_KEY);
  };

  const handleSubmit = async (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    if (!input.trim()) return;

    const userMessage: Message = { role: 'user', content: input };
    const newMessages = [...messages, userMessage];
    setMessages(newMessages);
    setInput('');
    setLoading(true);
    setError(null);

    // Create a simplified text-only chat history for the prompt
    const chatHistoryForPrompt = newMessages.map(msg => {
        const content = typeof msg.content === 'string' 
            ? msg.content 
            : `${msg.content.summary} ${msg.content.bulletPoints.join(' ')} ${msg.content.conclusion}`;
        return { role: msg.role, content };
    }).slice(0, -1); // Exclude the current user message from history for this turn

    try {
      const result = await answerFarmingQuestion({ 
          question: input,
          chatHistory: chatHistoryForPrompt
      });
      const assistantMessage: Message = { role: 'assistant', content: result };
      setMessages(prev => [...prev, assistantMessage]);
    } catch (e) {
      setError('The AI assistant is currently unavailable. Please try again later.');
      console.error(e);
       // Revert user message on error
      setMessages(prev => prev.slice(0, -1));
    }
    setLoading(false);
  };

  const renderMessageContent = (content: string | StructuredAnswer) => {
    if (typeof content === 'string') {
        return <p className="text-sm">{content}</p>;
    }
    return (
        <div className="space-y-3">
            <p className="text-sm">{content.summary}</p>
            <ul className="space-y-2 list-disc pl-5 text-sm">
                {content.bulletPoints.map((point, i) => <li key={i}>{point}</li>)}
            </ul>
            <p className="text-sm">{content.conclusion}</p>
        </div>
    );
  };

  return (
    <Card className="h-[70vh] flex flex-col">
      <CardHeader className="flex-row items-start justify-between">
        <div>
            <CardTitle className="font-headline">AI Farming Assistant</CardTitle>
            <CardDescription>Ask any question about farming practices, crop diseases, or market trends.</CardDescription>
        </div>
        <Button variant="ghost" size="icon" onClick={handleNewChat} aria-label="New Chat">
            <Trash2 className="w-5 h-5" />
        </Button>
      </CardHeader>
      <CardContent className="flex-grow flex flex-col min-h-0">
        <ScrollArea className="flex-grow pr-4 -mr-4" ref={scrollAreaRef}>
          <div className="space-y-4">
            {messages.length === 0 && !loading && (
                 <div className="flex flex-col items-center justify-center h-full text-center text-muted-foreground p-8">
                    <Bot className="w-12 h-12 mb-4"/>
                    <p className="font-semibold">Chat Session is Empty</p>
                    <p className="text-sm">Your conversation with the AI assistant will appear here.</p>
                </div>
            )}
            {messages.map((message, index) => (
              <div key={index} className={cn('flex items-start gap-3', message.role === 'user' ? 'justify-end' : 'justify-start')}>
                {message.role === 'assistant' && (
                  <Avatar className="w-8 h-8">
                    <AvatarFallback className="bg-primary text-primary-foreground"><Bot className="w-5 h-5"/></AvatarFallback>
                  </Avatar>
                )}
                <div className={cn('p-3 rounded-lg max-w-sm md:max-w-md lg:max-w-lg', message.role === 'user' ? 'bg-primary text-primary-foreground' : 'bg-muted')}>
                  {renderMessageContent(message.content)}
                </div>
                {message.role === 'user' && (
                    <Avatar className="w-8 h-8">
                        <AvatarFallback><UserIcon className="w-5 h-5"/></AvatarFallback>
                    </Avatar>
                )}
              </div>
            ))}
            {loading && (
                 <div className="flex items-start gap-3 justify-start">
                    <Avatar className="w-8 h-8">
                        <AvatarFallback className="bg-primary text-primary-foreground"><Bot className="w-5 h-5"/></AvatarFallback>
                    </Avatar>
                    <div className="p-3 rounded-lg bg-muted flex items-center">
                        <Loader2 className="h-5 w-5 animate-spin text-muted-foreground" />
                    </div>
                </div>
            )}
          </div>
        </ScrollArea>
        <div className="mt-4">
            {error && (
                <Alert variant="destructive" className="mb-4">
                    <AlertTitle>Error</AlertTitle>
                    <AlertDescription>{error}</AlertDescription>
                </Alert>
            )}
            <form onSubmit={handleSubmit} className="flex gap-2">
                <Input
                    value={input}
                    onChange={handleInputChange}
                    placeholder="e.g., What is the best way to control aphids?"
                    disabled={loading}
                />
                <Button type="submit" disabled={loading || !input.trim()}>
                    <Send className="h-4 w-4" />
                </Button>
            </form>
        </div>
      </CardContent>
    </Card>
  );
}
