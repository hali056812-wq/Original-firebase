'use client';

import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { Button } from '@/components/ui/button';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuGroup,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
  DropdownMenuSub,
  DropdownMenuSubTrigger,
  DropdownMenuSubContent,
  DropdownMenuPortal
} from '@/components/ui/dropdown-menu';
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog"
import { useAuth } from '@/hooks/use-auth';
import { LogIn, LogOut, User as UserIcon, Loader2, Monitor, Sun, Moon, Users, RefreshCw } from 'lucide-react';
import Link from 'next/link';
import { useTheme } from 'next-themes';
import { useFarmData } from '@/hooks/use-farm-data';
import { useState } from 'react';

const ADMIN_EMAIL = 'hali056812@gmail.com';

export function UserNav() {
  const { user, logout, loading } = useAuth();
  const { setTheme } = useTheme();
  const { farmData, updateFarmData, resetProfile } = useFarmData();
  const [showResetDialog, setShowResetDialog] = useState(false);

  if (loading) {
    return (
        <Button variant="outline" disabled>
            <Loader2 className="mr-2 h-4 w-4 animate-spin" />
            Loading...
        </Button>
    )
  }

  if (!user) {
    return (
      <Link href="/login">
        <Button variant="outline">
          <LogIn className="mr-2 h-4 w-4" />
          Login / Sign Up
        </Button>
      </Link>
    )
  }

  const handleThemeChange = (theme: string) => {
    setTheme(theme);
    updateFarmData({ theme } as any);
  }

  const getInitials = () => {
    if (farmData.displayName) return farmData.displayName[0].toUpperCase();
    if (user.displayName) return user.displayName[0].toUpperCase();
    if (user.email) return user.email[0].toUpperCase();
    return <UserIcon />;
  }
  
  const isAdmin = user.email === ADMIN_EMAIL;

  return (
    <>
    <DropdownMenu>
      <DropdownMenuTrigger asChild>
        <Button variant="ghost" className="relative h-10 w-10 rounded-full">
          <Avatar className="h-10 w-10">
            <AvatarImage src={user.photoURL || ''} alt="User avatar" />
            <AvatarFallback>{getInitials()}</AvatarFallback>
          </Avatar>
        </Button>
      </DropdownMenuTrigger>
      <DropdownMenuContent className="w-56" align="end" forceMount>
        <DropdownMenuLabel className="font-normal">
          <div className="flex flex-col space-y-1">
            <p className="text-sm font-medium leading-none">{farmData.displayName || user.displayName || 'Farmer'}</p>
            <p className="text-xs leading-none text-muted-foreground">
              {user.email}
            </p>
          </div>
        </DropdownMenuLabel>
        <DropdownMenuSeparator />
        <DropdownMenuGroup>
          <Link href="/dashboard/profile">
            <DropdownMenuItem>
              <UserIcon className="mr-2 h-4 w-4" />
              <span>Profile</span>
            </DropdownMenuItem>
          </Link>
           <Link href="/dashboard/community">
            <DropdownMenuItem>
              <Users className="mr-2 h-4 w-4" />
              <span>Community</span>
            </DropdownMenuItem>
          </Link>
          <DropdownMenuSub>
            <DropdownMenuSubTrigger>
                <Sun className="mr-2 h-4 w-4 rotate-0 scale-100 transition-all dark:-rotate-90 dark:scale-0" />
                <Moon className="absolute mr-2 h-4 w-4 rotate-90 scale-0 transition-all dark:rotate-0 dark:scale-100" />
                <span>Theme</span>
            </DropdownMenuSubTrigger>
            <DropdownMenuPortal>
                <DropdownMenuSubContent>
                    <DropdownMenuItem onClick={() => handleThemeChange('light')}>
                        <Sun className="mr-2 h-4 w-4" />
                        <span>Light</span>
                    </DropdownMenuItem>
                    <DropdownMenuItem onClick={() => handleThemeChange('dark')}>
                        <Moon className="mr-2 h-4 w-4" />
                        <span>Dark</span>
                    </DropdownMenuItem>
                    <DropdownMenuItem onClick={() => handleThemeChange('system')}>
                        <Monitor className="mr-2 h-4 w-4" />
                        <span>System</span>
                    </DropdownMenuItem>
                </DropdownMenuSubContent>
            </DropdownMenuPortal>
          </DropdownMenuSub>
        </DropdownMenuGroup>
        <DropdownMenuSeparator />
        {isAdmin && (
            <>
            <DropdownMenuItem onSelect={(e) => { e.preventDefault(); setShowResetDialog(true); }} className="text-destructive focus:text-destructive focus:bg-destructive/10">
                <RefreshCw className="mr-2 h-4 w-4" />
                <span>Reset Profile</span>
            </DropdownMenuItem>
            <DropdownMenuSeparator />
            </>
        )}
        <DropdownMenuItem onClick={logout}>
          <LogOut className="mr-2 h-4 w-4" />
          <span>Log out</span>
        </DropdownMenuItem>
      </DropdownMenuContent>
    </DropdownMenu>

    <AlertDialog open={showResetDialog} onOpenChange={setShowResetDialog}>
        <AlertDialogContent>
            <AlertDialogHeader>
            <AlertDialogTitle>Are you sure?</AlertDialogTitle>
            <AlertDialogDescription>
                This will permanently reset your profile data, including farm setup and preferences. This action cannot be undone. It is intended for testing purposes only.
            </AlertDialogDescription>
            </AlertDialogHeader>
            <AlertDialogFooter>
            <AlertDialogCancel>Cancel</AlertDialogCancel>
            <AlertDialogAction 
                onClick={() => {
                    resetProfile();
                    setShowResetDialog(false);
                }}
                className="bg-destructive hover:bg-destructive/90 text-destructive-foreground">
                Yes, reset my profile
            </AlertDialogAction>
            </AlertDialogFooter>
        </AlertDialogContent>
    </AlertDialog>
    </>
  );
}
