'use client';

import { useState, useRef, useEffect } from 'react';
import Image from 'next/image';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { analyzePlantHealthFromImage, AnalyzePlantHealthFromImageOutput } from '@/ai/flows/analyze-plant-health-from-image';
import { answerPlantDiagnosisQuestion, AnswerPlantDiagnosisQuestionOutput } from '@/ai/flows/answer-plant-diagnosis-question';
import { Loader2, Upload, Sparkles, AlertTriangle, Send, Bot, User as UserIcon } from 'lucide-react';
import { Alert, AlertDescription, AlertTitle } from '../ui/alert';
import { PlaceHolderImages } from '@/lib/placeholder-images';
import { Input } from '../ui/input';
import { ScrollArea } from '../ui/scroll-area';
import { Avatar, AvatarFallback } from '../ui/avatar';
import { cn } from '@/lib/utils';

type StructuredAnswer = AnalyzePlantHealthFromImageOutput | AnswerPlantDiagnosisQuestionOutput;

interface Message {
  role: 'user' | 'assistant';
  content: string | StructuredAnswer;
}

export function PlantScanner() {
  const [imagePreview, setImagePreview] = useState<string | null>(null);
  const [imageFile, setImageFile] = useState<File | null>(null);
  const [diagnosis, setDiagnosis] = useState<string | null>(null);
  const [messages, setMessages] = useState<Message[]>([]);
  const [loading, setLoading] = useState(false);
  const [loadingAnswer, setLoadingAnswer] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [chatInput, setChatInput] = useState('');

  const fileInputRef = useRef<HTMLInputElement>(null);
  const scrollAreaRef = useRef<HTMLDivElement>(null);

  const placeholderImage = PlaceHolderImages.find(p => p.id === 'plant-scan-placeholder');

  useEffect(() => {
    if (scrollAreaRef.current) {
        const viewport = scrollAreaRef.current.querySelector('div[data-radix-scroll-area-viewport]');
        if (viewport) {
            viewport.scrollTop = viewport.scrollHeight;
        }
    }
  }, [messages]);

  const handleFileChange = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (file) {
      setImageFile(file);
      const reader = new FileReader();
      reader.onloadend = () => {
        setImagePreview(reader.result as string);
        setDiagnosis(null);
        setMessages([]);
        setError(null);
      };
      reader.readAsDataURL(file);
    }
  };

  const handleScan = async () => {
    if (!imagePreview) return;
    setLoading(true);
    setError(null);
    setDiagnosis(null);
    setMessages([]);

    try {
      const result = await analyzePlantHealthFromImage({ photoDataUri: imagePreview });
      const diagnosisText = `${result.summary} ${result.bulletPoints.join(' ')} ${result.conclusion}`;
      setDiagnosis(diagnosisText);
      setMessages([{ role: 'assistant', content: result }]);
    } catch (e) {
      setError('Failed to analyze plant. Please try a different image.');
      console.error(e);
    }
    setLoading(false);
  };
  
  const handleChatSubmit = async (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    if (!chatInput.trim() || !imagePreview || !diagnosis) return;

    const userMessage: Message = { role: 'user', content: chatInput };
    const newMessages = [...messages, userMessage];
    setMessages(newMessages);
    setChatInput('');
    setLoadingAnswer(true);
    setError(null);
    
    // Create a simplified text-only chat history for the prompt
    const chatHistoryForPrompt = messages.map(msg => {
        const content = typeof msg.content === 'string' ? msg.content : msg.content.summary;
        return { role: msg.role, content };
    });

    try {
      const result = await answerPlantDiagnosisQuestion({
        photoDataUri: imagePreview,
        diagnosis,
        question: chatInput,
        chatHistory: chatHistoryForPrompt,
      });
      const assistantMessage: Message = { role: 'assistant', content: result };
      setMessages(prev => [...prev, assistantMessage]);
    } catch (e) {
      setError('The AI assistant is currently unavailable. Please try again later.');
      console.error(e);
    }
    setLoadingAnswer(false);
  };

  const triggerFileSelect = () => fileInputRef.current?.click();

  const renderMessageContent = (content: string | StructuredAnswer) => {
    if (typeof content === 'string') {
        return <p className="text-sm">{content}</p>;
    }
    return (
        <div className="space-y-3">
            <p className="text-sm">{content.summary}</p>
            <ul className="space-y-2 list-disc pl-5 text-sm">
                {content.bulletPoints.map((point, i) => <li key={i}>{point}</li>)}
            </ul>
            <p className="text-sm">{content.conclusion}</p>
        </div>
    );
  };

  return (
    <Card>
      <CardHeader>
        <CardTitle className="font-headline">Plant Health Scanner</CardTitle>
        <CardDescription>Upload a picture of a plant to get an AI-powered health diagnosis and ask follow-up questions.</CardDescription>
      </CardHeader>
      <CardContent className="grid md:grid-cols-2 gap-8 items-start">
        <div className="flex flex-col items-center gap-4">
          <div className="relative w-full aspect-video rounded-lg overflow-hidden border border-dashed flex items-center justify-center bg-muted">
            {imagePreview ? (
              <Image src={imagePreview} alt="Plant preview" layout="fill" objectFit="contain" />
            ) : placeholderImage && (
              <Image src={placeholderImage.imageUrl} alt={placeholderImage.description} layout="fill" objectFit="cover" data-ai-hint={placeholderImage.imageHint} />
            )}
             {!imagePreview && <span className="text-muted-foreground">Image preview will appear here</span>}
          </div>
          <input
            type="file"
            accept="image/*"
            ref={fileInputRef}
            onChange={handleFileChange}
            className="hidden"
          />
          <div className="flex w-full gap-2">
            <Button onClick={triggerFileSelect} variant="outline" className="w-full">
              <Upload className="w-4 h-4 mr-2" />
              {imageFile ? 'Change Image' : 'Select Image'}
            </Button>
            <Button onClick={handleScan} disabled={!imagePreview || loading} className="w-full">
              {loading ? (
                <Loader2 className="mr-2 h-4 w-4 animate-spin" />
              ) : (
                <Sparkles className="w-4 h-4 mr-2" />
              )}
              Scan Plant
            </Button>
          </div>
        </div>

        <div className="h-full flex flex-col">
          <h3 className="font-bold font-headline mb-2">Diagnosis & Chat</h3>
          <div className="h-full min-h-[300px] flex flex-col bg-muted rounded-lg p-4">
            {loading && (
              <div className="flex items-center justify-center h-full text-muted-foreground">
                <Loader2 className="mr-2 h-5 w-5 animate-spin" />
                <span>Analyzing...</span>
              </div>
            )}
            {!loading && !diagnosis && (
              <div className="flex items-center justify-center h-full text-muted-foreground">
                <p>Your plant's health report will appear here.</p>
              </div>
            )}
            
            {diagnosis && (
                <>
                <ScrollArea className="flex-grow pr-4 -mr-4" ref={scrollAreaRef}>
                    <div className="space-y-4">
                    {messages.map((message, index) => (
                        <div key={index} className={cn('flex items-start gap-3', message.role === 'user' ? 'justify-end' : 'justify-start')}>
                        {message.role === 'assistant' && (
                            <Avatar className="w-8 h-8">
                            <AvatarFallback className="bg-primary text-primary-foreground"><Bot className="w-5 h-5"/></AvatarFallback>
                            </Avatar>
                        )}
                        <div className={cn('p-3 rounded-lg max-w-sm', message.role === 'user' ? 'bg-primary text-primary-foreground' : 'bg-background')}>
                            {renderMessageContent(message.content)}
                        </div>
                        {message.role === 'user' && (
                            <Avatar className="w-8 h-8">
                                <AvatarFallback><UserIcon className="w-5 h-5"/></AvatarFallback>
                            </Avatar>
                        )}
                        </div>
                    ))}
                    {loadingAnswer && (
                        <div className="flex items-start gap-3 justify-start">
                            <Avatar className="w-8 h-8">
                                <AvatarFallback className="bg-primary text-primary-foreground"><Bot className="w-5 h-5"/></AvatarFallback>
                            </Avatar>
                            <div className="p-3 rounded-lg bg-background flex items-center">
                                <Loader2 className="h-5 w-5 animate-spin text-muted-foreground" />
                            </div>
                        </div>
                    )}
                    </div>
                </ScrollArea>
                <div className="mt-4">
                    {error && (
                        <Alert variant="destructive" className="mb-4">
                            <AlertTriangle className="h-4 w-4" />
                            <AlertTitle>Error</AlertTitle>
                            <AlertDescription>{error}</AlertDescription>
                        </Alert>
                    )}
                    <form onSubmit={handleChatSubmit} className="flex gap-2">
                        <Input
                            value={chatInput}
                            onChange={(e) => setChatInput(e.target.value)}
                            placeholder="Ask a follow-up question..."
                            disabled={loadingAnswer}
                        />
                        <Button type="submit" disabled={loadingAnswer || !chatInput.trim()}>
                            <Send className="h-4 w-4" />
                        </Button>
                    </form>
                </div>
                </>
            )}

            {!loading && error && !diagnosis && (
              <Alert variant="destructive" className="h-full">
                 <AlertTriangle className="h-4 w-4" />
                <AlertTitle>Analysis Failed</AlertTitle>
                <AlertDescription>{error}</AlertDescription>
              </Alert>
            )}

          </div>
        </div>
      </CardContent>
    </Card>
  );
}
