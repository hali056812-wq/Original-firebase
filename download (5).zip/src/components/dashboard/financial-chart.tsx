'use client';

import { BarChart, DollarSign } from 'lucide-react';
import {
  LineChart,
  Line,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
  ResponsiveContainer,
} from 'recharts';
import { format, subMonths, getMonth, getYear } from 'date-fns';
import type { FinancialEntry } from '@/hooks/use-farm-data';
import { formatCurrency, formatCompactCurrency } from '@/lib/utils';
import {
    ChartContainer,
    ChartTooltip,
    ChartTooltipContent,
    ChartLegend,
    ChartLegendContent,
  } from '@/components/ui/chart';

interface FinancialChartProps {
  data: FinancialEntry[];
}

const chartConfig = {
    sales: {
      label: 'Sales',
      color: 'hsl(var(--chart-2))',
    },
    costs: {
      label: 'Costs',
      color: 'hsl(var(--chart-1))',
    },
};

export function FinancialChart({ data }: FinancialChartProps) {
  const processData = () => {
    const last12Months = Array.from({ length: 12 }).map((_, i) => {
      const date = subMonths(new Date(), i);
      return {
        month: getMonth(date),
        year: getYear(date),
        name: format(date, 'MMM yy'),
        sales: 0,
        costs: 0,
      };
    }).reverse();

    data.forEach(entry => {
      const entryDate = new Date(entry.date);
      const entryMonth = getMonth(entryDate);
      const entryYear = getYear(entryDate);

      const monthData = last12Months.find(m => m.month === entryMonth && m.year === entryYear);

      if (monthData) {
        if (entry.type === 'sale') {
          monthData.sales += entry.amount;
        } else {
          monthData.costs += entry.amount;
        }
      }
    });

    return last12Months;
  };

  const chartData = processData();
  const noData = data.length === 0;

  if (noData) {
    return (
        <div className="flex flex-col items-center justify-center h-[250px] text-center p-4 border-2 border-dashed rounded-lg">
            <BarChart className="w-12 h-12 mb-2 text-muted-foreground" />
            <p className="font-semibold">No Financial Data</p>
            <p className="text-sm text-muted-foreground">Add transactions to see your financial performance chart.</p>
        </div>
    )
  }

  return (
    <div className="w-full overflow-x-auto">
      <ChartContainer config={chartConfig} className="min-h-[250px] w-full min-w-[500px]">
        <ResponsiveContainer width="100%" height={300}>
            <LineChart data={chartData} margin={{ top: 5, right: 20, left: -10, bottom: 5 }}>
                <CartesianGrid strokeDasharray="3 3" vertical={false} />
                <XAxis dataKey="name" stroke="hsl(var(--muted-foreground))" fontSize={12} tickLine={false} axisLine={false} />
                <YAxis stroke="hsl(var(--muted-foreground))" fontSize={12} tickLine={false} axisLine={false} tickFormatter={(value) => formatCompactCurrency(value as number)} />
                <ChartTooltip
                    cursor={false}
                    content={<ChartTooltipContent indicator="dot" formatter={(value, name) => <div>{`${chartConfig[name as keyof typeof chartConfig].label}: ${formatCurrency(value as number)}`}</div>} />}
                />
                <ChartLegend content={<ChartLegendContent />} />
                <Line
                    dataKey="costs"
                    type="monotone"
                    stroke="var(--color-costs)"
                    strokeWidth={2}
                    dot={false}
                />
                <Line
                    dataKey="sales"
                    type="monotone"
                    stroke="var(--color-sales)"
                    strokeWidth={2}
                    dot={false}
                />
            </LineChart>
        </ResponsiveContainer>
      </ChartContainer>
    </div>
  );
}
