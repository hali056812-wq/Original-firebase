'use client';

import { useState, useEffect } from 'react';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { z } from 'zod';
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from '@/components/ui/form';
import { Input } from '@/components/ui/input';
import { getCropRecommendations, type CropRecommendationOutput } from '@/ai/flows/crop-recommendation-from-user-location';
import { Loader2, Droplet, Sun, ChevronsRight, BarChart, DollarSign, BrainCircuit } from 'lucide-react';
import { Alert, AlertDescription, AlertTitle } from '../ui/alert';
import { useFarmData } from '@/hooks/use-farm-data';

const formSchema = z.object({
  location: z.string().min(1, 'Location is required'),
  soilData: z.string().min(1, 'Soil data is required'),
  climateConditions: z.string().min(1, 'Climate conditions are required'),
});

export function CropRecommendations() {
  const { farmData } = useFarmData();
  const [recommendations, setRecommendations] = useState<CropRecommendationOutput | null>(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const form = useForm<z.infer<typeof formSchema>>({
    resolver: zodResolver(formSchema),
    defaultValues: {
      location: '',
      soilData: '',
      climateConditions: '',
    },
  });

  useEffect(() => {
    if (farmData.zone) {
      form.setValue('location', farmData.zone);
    }
  }, [farmData.zone, form]);

  async function onSubmit(values: z.infer<typeof formSchema>) {
    setLoading(true);
    setError(null);
    setRecommendations(null);
    try {
      const result = await getCropRecommendations(values);
      setRecommendations(result);
    } catch (e) {
      setError('Failed to get recommendations. Please try again.');
      console.error(e);
    }
    setLoading(false);
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle className="font-headline">Crop Recommendations</CardTitle>
        <CardDescription>Enter your farm's details to get AI-powered crop suggestions.</CardDescription>
      </CardHeader>
      <CardContent>
        <Form {...form}>
          <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
            <div className="grid md:grid-cols-3 gap-4">
              <FormField
                control={form.control}
                name="location"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Location</FormLabel>
                    <FormControl>
                      <Input placeholder="e.g., Napa Valley, CA" {...field} />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              <FormField
                control={form.control}
                name="soilData"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Soil Data</FormLabel>
                    <FormControl>
                      <Input placeholder="e.g., Clay, pH 7.0" {...field} />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              <FormField
                control={form.control}
                name="climateConditions"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Climate Conditions</FormLabel>
                    <FormControl>
                      <Input placeholder="e.g., Temperate, 500mm rainfall" {...field} />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
            </div>
            <Button type="submit" disabled={loading} className="w-full md:w-auto">
              {loading && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
              Get Recommendations
            </Button>
          </form>
        </Form>

        {error && (
            <Alert variant="destructive" className="mt-6">
                <AlertTitle>Error</AlertTitle>
                <AlertDescription>{error}</AlertDescription>
            </Alert>
        )}

        {recommendations && (
          <div className="mt-8">
            <h3 className="text-xl font-bold font-headline mb-4">Recommended Crops</h3>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              {recommendations.cropRecommendations.map((crop, index) => (
                <Card key={index} className="flex flex-col">
                  <CardHeader>
                    <CardTitle>{crop.cropName}</CardTitle>
                    <CardDescription>{crop.season}</CardDescription>
                  </CardHeader>
                  <CardContent className="flex-grow space-y-3 text-sm">
                    <div className="flex items-center"><Droplet className="w-4 h-4 mr-2 text-primary"/> <strong>Water:</strong> <span className="ml-auto">{crop.waterNeeds}</span></div>
                    <div className="flex items-center"><Sun className="w-4 h-4 mr-2 text-primary"/> <strong>Sunlight:</strong> <span className="ml-auto">{crop.sunlight}</span></div>
                    <div className="flex items-center"><ChevronsRight className="w-4 h-4 mr-2 text-primary"/> <strong>Yield:</strong> <span className="ml-auto">{crop.yield}</span></div>
                    <div className="flex items-center"><DollarSign className="w-4 h-4 mr-2 text-primary"/> <strong>Revenue:</strong> <span className="ml-auto">{crop.revenue}</span></div>
                    <div className="flex items-center"><BrainCircuit className="w-4 h-4 mr-2 text-primary"/> <strong>Difficulty:</strong> <span className="ml-auto">{crop.difficulty}</span></div>
                  </CardContent>
                </Card>
              ))}
            </div>
          </div>
        )}
      </CardContent>
    </Card>
  );
}
