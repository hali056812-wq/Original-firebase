'use client';

import { zodResolver } from '@hookform/resolvers/zod';
import { useForm } from 'react-hook-form';
import { z } from 'zod';
import { Button } from '@/components/ui/button';
import {
  Form,
  FormControl,
  FormDescription,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from '@/components/ui/form';
import { RadioGroup, RadioGroupItem } from '@/components/ui/radio-group';
import { Input } from '@/components/ui/input';
import { useFarmData } from '@/hooks/use-farm-data';
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from '@/components/ui/card';
import { Loader2, Briefcase, Flower } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';
import { useEffect } from 'react';
import { useAuth } from '@/hooks/use-auth';

const formSchema = z.object({
  displayName: z.string().min(2, 'Display name must be at least 2 characters.'),
  zone: z.string().optional(),
  userType: z.enum(['commercial', 'hobbyist'], { required_error: 'Please select an option.'}),
});

type FormValues = z.infer<typeof formSchema>;


export function GetStartedForm() {
  const { farmData, updateFarmData, setIsDataEntered, skipSetup, loading } = useFarmData();
  const { user } = useAuth();
  const { toast } = useToast();

  const form = useForm<FormValues>({
    resolver: zodResolver(formSchema),
    defaultValues: {
      displayName: '',
      zone: '',
      userType: 'commercial',
    },
  });

  useEffect(() => {
    if (user && !loading) {
      form.reset({
        displayName: farmData.displayName || user.displayName || '',
        zone: '',
        userType: 'commercial',
      });
    }
  }, [user, loading, farmData.displayName, form]);

  if (loading) {
    return (
        <div className="container mx-auto px-4 py-8 md:px-6 md:py-12 flex items-center justify-center">
            <Card className="w-full max-w-xl flex items-center justify-center h-96">
                <Loader2 className="h-8 w-8 animate-spin text-muted-foreground" />
            </Card>
        </div>
    );
  }

  function onSubmit(values: FormValues) {
    updateFarmData({ ...values, isDataEntered: true });
    setIsDataEntered(true);
    toast({
        title: "Profile setup complete!",
        description: "Welcome to your AgriGenius dashboard."
    })
  }

  return (
    <div className="container mx-auto px-4 py-8 md:px-6 md:py-12 flex items-center justify-center">
      <Card className="w-full max-w-xl">
        <CardHeader>
          <CardTitle className="text-3xl font-headline">Welcome to AgriGenius!</CardTitle>
          <CardDescription>Just a few details to get your farm profile started.</CardDescription>
        </CardHeader>
        <Form {...form}>
          <form onSubmit={form.handleSubmit(onSubmit)}>
            <CardContent className="space-y-6">
                <FormField
                  control={form.control}
                  name="userType"
                  render={({ field }) => (
                    <FormItem className="space-y-3">
                      <FormLabel>What best describes you?</FormLabel>
                      <FormControl>
                        <RadioGroup
                          onValueChange={field.onChange}
                          defaultValue={field.value}
                          className="grid md:grid-cols-2 gap-4"
                        >
                          <FormItem>
                            <FormControl>
                                <RadioGroupItem value="commercial" id="commercial" className="peer sr-only" />
                            </FormControl>
                             <FormLabel htmlFor="commercial" className="flex flex-col items-center justify-between rounded-md border-2 border-muted bg-popover p-4 hover:bg-accent hover:text-accent-foreground peer-data-[state=checked]:border-primary [&:has([data-state=checked])]:border-primary">
                                <Briefcase className="mb-3 h-6 w-6" />
                                Commercial Farmer
                             </FormLabel>
                          </FormItem>
                          <FormItem>
                             <FormControl>
                                <RadioGroupItem value="hobbyist" id="hobbyist" className="peer sr-only" />
                             </FormControl>
                             <FormLabel htmlFor="hobbyist" className="flex flex-col items-center justify-between rounded-md border-2 border-muted bg-popover p-4 hover:bg-accent hover:text-accent-foreground peer-data-[state=checked]:border-primary [&:has([data-state=checked])]:border-primary">
                                <Flower className="mb-3 h-6 w-6" />
                                Hobbyist / Gardener
                            </FormLabel>
                          </FormItem>
                        </RadioGroup>
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <FormField
                    control={form.control}
                    name="displayName"
                    render={({ field }) => (
                        <FormItem>
                        <FormLabel>Your Name</FormLabel>
                        <FormControl>
                            <Input placeholder="e.g., Jane Doe" {...field} />
                        </FormControl>
                        <FormMessage />
                        </FormItem>
                    )}
                />
                <FormField
                    control={form.control}
                    name="zone"
                    render={({ field }) => (
                        <FormItem>
                        <FormLabel>Location / Zone (Optional)</FormLabel>
                        <FormControl>
                            <Input placeholder="e.g., San Francisco, CA or 94107" {...field} />
                        </FormControl>
                         <FormDescription>Used for local weather & advice</FormDescription>
                        <FormMessage />
                        </FormItem>
                    )}
                />
            </CardContent>
            <CardFooter className="flex justify-between">
              <Button type="button" variant="ghost" onClick={skipSetup}>Skip For Now</Button>
              <Button type="submit">Get Started</Button>
            </CardFooter>
          </form>
        </Form>
      </Card>
    </div>
  );
}
