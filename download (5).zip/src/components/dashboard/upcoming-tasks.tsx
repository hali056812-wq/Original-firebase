'use client';

import { useState } from 'react';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { z } from 'zod';
import { useFarmData, type Task } from '@/hooks/use-farm-data';
import { Card, CardContent, CardHeader, CardTitle, CardFooter } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Bell, CheckCircle2, Circle, Plus, Trash2, X, Droplet } from 'lucide-react';
import { cn } from '@/lib/utils';
import { format, formatDistanceToNowStrict, addDays } from 'date-fns';
import { Sheet, SheetContent, SheetDescription, SheetFooter, SheetHeader, SheetTitle, SheetTrigger } from '../ui/sheet';
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from '../ui/form';
import { Input } from '../ui/input';
import { Popover, PopoverTrigger, PopoverContent } from '../ui/popover';
import { CalendarIcon } from 'lucide-react';
import { Calendar } from '../ui/calendar';
import { Textarea } from '../ui/textarea';

const taskSchema = z.object({
  title: z.string().min(3, { message: "Title must be at least 3 characters." }),
  dueDate: z.date(),
  note: z.string().optional(),
});

type TaskFormValues = z.infer<typeof taskSchema>;

function AddTaskSheet({ children }: { children: React.ReactNode }) {
    const { addTask, farmData } = useFarmData();
    const [open, setOpen] = useState(false);

    const form = useForm<TaskFormValues>({
        resolver: zodResolver(taskSchema),
        defaultValues: { title: '', note: '' }
    });

    const onSubmit = (values: TaskFormValues) => {
        addTask({
            ...values,
            dueDate: values.dueDate.toISOString(),
            status: 'pending',
            type: 'manual'
        });
        form.reset();
        setOpen(false);
    }
    
    const addWateringReminder = () => {
        form.setValue('title', 'Water plants');
        form.setValue('dueDate', new Date());
    }
    
    return (
        <Sheet open={open} onOpenChange={setOpen}>
            <SheetTrigger asChild>{children}</SheetTrigger>
            <SheetContent>
                <SheetHeader>
                    <SheetTitle>Add a New Task</SheetTitle>
                    <SheetDescription>What needs to get done on the farm or in the garden?</SheetDescription>
                </SheetHeader>
                <Form {...form}>
                    <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6 py-6">
                         {farmData.userType === 'hobbyist' && (
                            <Button type="button" variant="outline" className="w-full" onClick={addWateringReminder}>
                                <Droplet className="mr-2" /> Remind me to water
                            </Button>
                         )}
                         <FormField
                            control={form.control}
                            name="title"
                            render={({ field }) => (
                                <FormItem>
                                <FormLabel>Task Title</FormLabel>
                                <FormControl>
                                    <Input placeholder="e.g., Fertilize corn field" {...field} />
                                </FormControl>
                                <FormMessage />
                                </FormItem>
                            )}
                        />
                         <FormField
                            control={form.control}
                            name="dueDate"
                            render={({ field }) => (
                                <FormItem className="flex flex-col">
                                <FormLabel>Due Date</FormLabel>
                                <Popover><PopoverTrigger asChild><FormControl>
                                    <Button variant={"outline"} className={cn("pl-3 text-left font-normal", !field.value && "text-muted-foreground")}>
                                    {field.value ? format(field.value, "PPP") : <span>Pick a date</span>} <CalendarIcon className="ml-auto h-4 w-4 opacity-50" />
                                    </Button></FormControl></PopoverTrigger><PopoverContent className="w-auto p-0" align="start"><Calendar mode="single" selected={field.value} onSelect={field.onChange} initialFocus /></PopoverContent></Popover>
                                <FormMessage />
                                </FormItem>
                            )}
                        />
                        <FormField
                            control={form.control}
                            name="note"
                            render={({ field }) => (
                                <FormItem>
                                <FormLabel>Notes (Optional)</FormLabel>
                                <FormControl>
                                    <Textarea placeholder="Add any extra details..." {...field} />
                                </FormControl>
                                <FormMessage />
                                </FormItem>
                            )}
                        />
                         <SheetFooter>
                            <Button type="submit">Save Task</Button>
                        </SheetFooter>
                    </form>
                </Form>
            </SheetContent>
        </Sheet>
    )
}

function DueDateBadge({ dueDate }: { dueDate: string }) {
    const due = new Date(dueDate);
    const now = new Date();
    now.setHours(0,0,0,0); // Set to start of day for comparison
    due.setHours(0,0,0,0);
    
    const isPast = due < now;
    let distance = formatDistanceToNowStrict(due, { addSuffix: true });
    
    if (due.getTime() === now.getTime()) {
        distance = 'Today';
    }


    return (
        <span className={cn(
            "text-xs font-medium px-2 py-0.5 rounded-full whitespace-nowrap",
            isPast ? "bg-destructive/20 text-destructive" : "bg-muted text-muted-foreground"
        )}>
            {distance}
        </span>
    )
}

export function UpcomingTasks() {
    const { farmData, updateTask, deleteTask } = useFarmData();
    const tasks = (farmData.tasks || []).filter(t => t.status === 'pending');

    const sortedTasks = tasks.sort((a, b) => new Date(a.dueDate).getTime() - new Date(b.dueDate).getTime());
    const nextTasks = sortedTasks.slice(0, 4);

    const handleToggle = (task: Task) => {
        updateTask(task.id, { status: task.status === 'pending' ? 'completed' : 'pending' });
    }

    return (
        <Card className="h-full flex flex-col bg-card border-l-4 border-l-emerald-500">
            <CardHeader className="flex-row items-center justify-between">
                <CardTitle className="font-headline flex items-center gap-2 text-base">
                    <Bell className="text-muted-foreground"/>
                    Upcoming Tasks
                </CardTitle>
                 <AddTaskSheet>
                    <Button variant="ghost" size="icon"><Plus className="w-5 h-5"/></Button>
                 </AddTaskSheet>
            </CardHeader>
            <CardContent className="flex-grow">
                {nextTasks.length > 0 ? (
                    <div className="space-y-3">
                        {nextTasks.map(task => (
                            <div key={task.id} className="flex items-center gap-3 text-sm">
                                <button onClick={() => handleToggle(task)}>
                                    {task.status === 'completed' ? <CheckCircle2 className="w-5 h-5 text-emerald-500" /> : <Circle className="w-5 h-5 text-muted-foreground" />}
                                </button>
                                <div className="flex-grow">
                                    <p className={cn("font-medium", task.status === 'completed' && 'line-through text-muted-foreground')}>{task.title}</p>
                                    {task.type === 'suggested' && <span className="text-xs text-primary">Suggested</span>}
                                </div>
                                <DueDateBadge dueDate={task.dueDate} />
                                {task.type === 'suggested' ? (
                                    <button onClick={() => deleteTask(task.id)}><X className="w-4 h-4 text-muted-foreground hover:text-destructive"/></button>
                                ) : (
                                    <button onClick={() => deleteTask(task.id)}><Trash2 className="w-4 h-4 text-muted-foreground hover:text-destructive"/></button>
                                )}
                            </div>
                        ))}
                    </div>
                ) : (
                     <AddTaskSheet>
                        <button className="w-full h-full flex flex-col items-center justify-center text-center text-muted-foreground p-4 border-2 border-dashed rounded-lg hover:bg-accent">
                            No upcoming tasks.
                            <span className="font-normal mt-1">Tap to add one.</span>
                        </button>
                    </AddTaskSheet>
                )}
            </CardContent>
            {sortedTasks.length > 4 && (
                <CardFooter>
                    <Button variant="secondary" className="w-full" disabled>View all ({sortedTasks.length})</Button>
                </CardFooter>
            )}
        </Card>
    );
}
