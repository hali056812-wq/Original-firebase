'use client';

import { useState } from 'react';
import { useForm, Controller } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { z } from 'zod';
import { useFarmData } from '@/hooks/use-farm-data';
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Form, FormControl, FormDescription, FormField, FormItem, FormLabel, FormMessage } from '@/components/ui/form';
import { RadioGroup, RadioGroupItem } from '@/components/ui/radio-group';
import { Checkbox } from '@/components/ui/checkbox';
import { Loader2 } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';

const mainProducts = [
  { id: 'grains', label: 'Grains' },
  { id: 'vegetables', label: 'Vegetables' },
  { id: 'fruits', label: 'Fruits' },
  { id: 'livestock', label: 'Livestock' },
  { id: 'dairy', label: 'Dairy' },
  { id: 'other', label: 'Other' },
] as const;

const setupSchema = z.object({
  farmName: z.string().optional(),
  mainProducts: z.array(z.string()).optional(),
  trackingStyle: z.enum(['simple', 'by_field'], { required_error: 'Please select a tracking style.' }),
  firstFieldName: z.string().optional(),
  firstFieldCrop: z.string().optional(),
}).refine(data => {
    if (data.trackingStyle === 'by_field' && !data.firstFieldName) {
        return false;
    }
    return true;
}, {
    message: 'Field name is required when tracking by fields.',
    path: ['firstFieldName'],
});

type SetupFormValues = z.infer<typeof setupSchema>;

export function FarmSetupForm() {
  const { updateFarmData, addField } = useFarmData();
  const { toast } = useToast();
  const [isSubmitting, setIsSubmitting] = useState(false);

  const form = useForm<SetupFormValues>({
    resolver: zodResolver(setupSchema),
    defaultValues: {
      farmName: '',
      mainProducts: [],
      trackingStyle: 'simple',
      firstFieldName: '',
      firstFieldCrop: '',
    },
  });

  const trackingStyle = form.watch('trackingStyle');

  function onSubmit(values: SetupFormValues) {
    setIsSubmitting(true);
    
    const farmDataToUpdate = {
        farmName: values.farmName,
        mainProducts: values.mainProducts,
        trackingStyle: values.trackingStyle,
        isFarmSetupComplete: true,
    };

    if (values.trackingStyle === 'by_field' && values.firstFieldName) {
        addField({
            name: values.firstFieldName,
            crop: values.firstFieldCrop || 'General',
            size: 1, // Default size
            sizeUnit: 'acres', // Default unit
        });
    }

    updateFarmData(farmDataToUpdate);

    toast({
        title: "Farm setup complete!",
        description: "You can now start managing your farm's business."
    });
    
    // No need to set isSubmitting to false, as the component will unmount
  }

  const handleSkip = () => {
     updateFarmData({
        isFarmSetupComplete: true,
        trackingStyle: 'simple', // Default if skipped
     });
     toast({
        title: "Setup Skipped",
        description: "You can always configure your farm details later."
    });
  }

  return (
    <Card className="max-w-2xl mx-auto">
      <CardHeader>
        <CardTitle className="text-3xl font-headline">Set Up Your Farm</CardTitle>
        <CardDescription>This helps us personalize your farm management. You can change it later.</CardDescription>
      </CardHeader>
      <Form {...form}>
        <form onSubmit={form.handleSubmit(onSubmit)}>
          <CardContent className="space-y-8">
            <FormField
              control={form.control}
              name="farmName"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Farm Name (Optional)</FormLabel>
                  <FormControl>
                    <Input placeholder="e.g., Green Valley Farms" {...field} />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />

            <FormField
              control={form.control}
              name="mainProducts"
              render={() => (
                <FormItem>
                  <div className="mb-4">
                    <FormLabel className="text-base">What do you mainly produce?</FormLabel>
                    <FormDescription>
                      You can choose more than one.
                    </FormDescription>
                  </div>
                  <div className="grid grid-cols-2 md:grid-cols-3 gap-2">
                    {mainProducts.map((item) => (
                      <FormField
                        key={item.id}
                        control={form.control}
                        name="mainProducts"
                        render={({ field }) => {
                          return (
                            <FormItem
                              key={item.id}
                              className="flex flex-row items-start space-x-3 space-y-0"
                            >
                              <FormControl>
                                <Checkbox
                                  checked={field.value?.includes(item.id)}
                                  onCheckedChange={(checked) => {
                                    return checked
                                      ? field.onChange([...(field.value || []), item.id])
                                      : field.onChange(
                                          field.value?.filter(
                                            (value) => value !== item.id
                                          )
                                        )
                                  }}
                                />
                              </FormControl>
                              <FormLabel className="font-normal">
                                {item.label}
                              </FormLabel>
                            </FormItem>
                          )
                        }}
                      />
                    ))}
                  </div>
                  <FormMessage />
                </FormItem>
              )}
            />

            <FormField
              control={form.control}
              name="trackingStyle"
              render={({ field }) => (
                <FormItem className="space-y-3">
                  <FormLabel>How detailed do you want to track your farm?</FormLabel>
                  <FormControl>
                    <RadioGroup
                      onValueChange={field.onChange}
                      defaultValue={field.value}
                      className="grid md:grid-cols-2 gap-4"
                    >
                      <FormItem>
                        <FormControl>
                          <RadioGroupItem value="simple" id="simple" className="peer sr-only" />
                        </FormControl>
                        <FormLabel htmlFor="simple" className="flex flex-col rounded-md border-2 border-muted bg-popover p-4 hover:bg-accent hover:text-accent-foreground peer-data-[state=checked]:border-primary [&:has([data-state=checked])]:border-primary">
                          <p className="font-semibold">Simple Totals Only</p>
                          <p className="text-xs text-muted-foreground mt-1">Just track total sales, costs, and profit for the whole farm.</p>
                        </FormLabel>
                      </FormItem>
                      <FormItem>
                        <FormControl>
                          <RadioGroupItem value="by_field" id="by_field" className="peer sr-only" />
                        </FormControl>
                        <FormLabel htmlFor="by_field" className="flex flex-col rounded-md border-2 border-muted bg-popover p-4 hover:bg-accent hover:text-accent-foreground peer-data-[state=checked]:border-primary [&:has([data-state=checked])]:border-primary">
                           <p className="font-semibold">By Fields/Plots (Advanced)</p>
                           <p className="text-xs text-muted-foreground mt-1">Track money for each field or area separately.</p>
                        </FormLabel>
                      </FormItem>
                    </RadioGroup>
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />
            
            {trackingStyle === 'by_field' && (
                <div className="p-4 border-l-4 border-primary bg-accent/50 rounded-r-lg space-y-4">
                     <h3 className="font-semibold">Create your first field/plot</h3>
                     <FormField
                        control={form.control}
                        name="firstFieldName"
                        render={({ field }) => (
                            <FormItem>
                            <FormLabel>Field Name</FormLabel>
                            <FormControl>
                                <Input placeholder="e.g., North Field" {...field} />
                            </FormControl>
                            <FormMessage />
                            </FormItem>
                        )}
                    />
                    <FormField
                        control={form.control}
                        name="firstFieldCrop"
                        render={({ field }) => (
                            <FormItem>
                            <FormLabel>Main Crop (Optional)</FormLabel>
                            <FormControl>
                                <Input placeholder="e.g., Corn" {...field} />
                            </FormControl>
                            <FormMessage />
                            </FormItem>
                        )}
                    />
                </div>
            )}

          </CardContent>
          <CardFooter className="flex justify-between">
            <Button type="button" variant="ghost" onClick={handleSkip} disabled={isSubmitting}>Skip for now</Button>
            <Button type="submit" disabled={isSubmitting}>
              {isSubmitting && <Loader2 className="animate-spin" />}
              Continue
            </Button>
          </CardFooter>
        </form>
      </Form>
    </Card>
  );
}
