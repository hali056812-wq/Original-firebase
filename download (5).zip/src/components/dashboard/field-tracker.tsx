'use client';

import { useState } from 'react';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { z } from 'zod';
import { Card, CardContent, CardDescription, CardHeader, CardTitle, CardFooter } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from '@/components/ui/form';
import { useFarmData } from '@/hooks/use-farm-data';
import { PlusCircle, Trash2, Loader2, LandPlot } from 'lucide-react';
import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from '@/components/ui/accordion';
import { useToast } from '@/hooks/use-toast';

const fieldSchema = z.object({
  name: z.string().min(1, 'Field name is required.'),
  size: z.coerce.number().min(0.1, 'Size must be greater than 0.'),
  sizeUnit: z.enum(['acres', 'hectares']),
  crop: z.string().min(1, 'Crop name is required.'),
});

export function FieldTracker() {
  const { farmData, addField, deleteField, loading } = useFarmData();
  const { toast } = useToast();
  const [isSubmitting, setIsSubmitting] = useState(false);

  const fieldForm = useForm<z.infer<typeof fieldSchema>>({
    resolver: zodResolver(fieldSchema),
    defaultValues: { name: '', size: 1, sizeUnit: 'acres', crop: '' },
  });

  const onFieldSubmit = (values: z.infer<typeof fieldSchema>) => {
    setIsSubmitting(true);
    addField(values);
    toast({ title: 'Field Added', description: `${values.name} has been added.` });
    fieldForm.reset();
    setIsSubmitting(false);
  };

  const handleDeleteField = (fieldId: string, fieldName: string) => {
    // Optional: Add a confirmation dialog here
    deleteField(fieldId);
    toast({ variant: 'destructive', title: 'Field Removed', description: `${fieldName} and its financial entries have been removed.` });
  };

  return (
    <div className="grid md:grid-cols-3 gap-8 items-start">
      <Card className="md:col-span-1">
        <CardHeader>
          <CardTitle className="font-headline">Add New Field</CardTitle>
          <CardDescription>Add a new plot or field to your farm to track it separately.</CardDescription>
        </CardHeader>
        <Form {...fieldForm}>
          <form onSubmit={fieldForm.handleSubmit(onFieldSubmit)}>
            <CardContent className="space-y-4">
              <FormField control={fieldForm.control} name="name" render={({ field }) => (<FormItem><FormLabel>Field Name</FormLabel><FormControl><Input placeholder="e.g., North Pasture" {...field} /></FormControl><FormMessage /></FormItem>)} />
              <FormField control={fieldForm.control} name="crop" render={({ field }) => (<FormItem><FormLabel>Primary Crop/Use</FormLabel><FormControl><Input placeholder="e.g., Corn" {...field} /></FormControl><FormMessage /></FormItem>)} />
              <div className="flex gap-4">
                <FormField control={fieldForm.control} name="size" render={({ field }) => (<FormItem className="flex-1"><FormLabel>Size</FormLabel><FormControl><Input type="number" {...field} /></FormControl><FormMessage /></FormItem>)} />
                <FormField control={fieldForm.control} name="sizeUnit" render={({ field }) => (<FormItem className="w-1/3"><FormLabel>Unit</FormLabel><Select onValueChange={field.onChange} defaultValue={field.value}><FormControl><SelectTrigger><SelectValue /></SelectTrigger></FormControl><SelectContent><SelectItem value="acres">Acres</SelectItem><SelectItem value="hectares">Hectares</SelectItem></SelectContent></Select><FormMessage /></FormItem>)} />
              </div>
            </CardContent>
            <CardFooter>
              <Button type="submit" disabled={isSubmitting} className="w-full">
                {isSubmitting ? <Loader2 className="animate-spin" /> : <PlusCircle />} Add Field
              </Button>
            </CardFooter>
          </form>
        </Form>
      </Card>
      
      <Card className="md:col-span-2">
        <CardHeader>
          <CardTitle className="font-headline">Your Fields</CardTitle>
          <CardDescription>Manage fields for detailed financial tracking.</CardDescription>
        </CardHeader>
        <CardContent>
          {loading ? (
            <div className="flex items-center justify-center h-48"><Loader2 className="animate-spin text-muted-foreground" /></div>
          ) : farmData.fields && farmData.fields.length > 0 ? (
            <Accordion type="single" collapsible className="w-full">
              {farmData.fields.map(field => (
                <AccordionItem value={field.id} key={field.id}>
                    <div className="flex items-center w-full">
                        <AccordionTrigger className="flex-1 hover:no-underline">
                            <div className="flex flex-col text-left">
                                <span className="font-bold">{field.name}</span>
                                <span className="text-sm text-muted-foreground">{field.crop} - {field.size} {field.sizeUnit}</span>
                            </div>
                        </AccordionTrigger>
                        <Button variant="ghost" size="icon" onClick={() => handleDeleteField(field.id, field.name)} className="ml-2">
                            <Trash2 className="text-destructive" />
                        </Button>
                    </div>
                  <AccordionContent>
                    <div className="p-4 bg-muted/50 rounded-md">
                        <p className="text-sm text-muted-foreground">
                            All costs and sales for this field can be tracked in the 'Business' tab. Entries associated with this field will be removed if the field is deleted.
                        </p>
                    </div>
                  </AccordionContent>
                </AccordionItem>
              ))}
            </Accordion>
          ) : (
            <div className="flex flex-col items-center justify-center h-48 border-2 border-dashed rounded-lg text-center p-4">
              <LandPlot className="w-10 h-10 mb-2 text-muted-foreground" />
              <p className="font-semibold">No Fields Added Yet</p>
              <p className="text-sm text-muted-foreground">Use the form on the left to add a field and start tracking it separately.</p>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
