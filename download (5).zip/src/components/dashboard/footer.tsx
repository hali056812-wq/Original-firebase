'use client';

export function DashboardFooter() {
  return (
    <footer className="py-6 mt-auto border-t">
      <div className="container text-center text-sm text-muted-foreground">
        © Smart Farm Assistant – Empowering Farmers with AI
      </div>
    </footer>
  );
}
