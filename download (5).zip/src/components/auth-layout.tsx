import Image from 'next/image';
import { PlaceHolderImages } from '@/lib/placeholder-images';

export default function AuthLayout({ children }: { children: React.ReactNode }) {
  const heroImage = PlaceHolderImages.find(p => p.id === 'hero-background');

  return (
    <main className="relative flex items-center justify-center min-h-screen bg-background">
      {heroImage && (
        <Image
          src={heroImage.imageUrl}
          alt={heroImage.description}
          fill
          className="object-cover"
          data-ai-hint={heroImage.imageHint}
          priority
        />
      )}
      <div className="absolute inset-0 bg-black/60" />
      <div className="relative z-10 w-full px-4">{children}</div>
    </main>
  );
}
