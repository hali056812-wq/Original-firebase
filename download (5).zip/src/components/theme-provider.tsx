'use client';

import * as React from 'react';
import { ThemeProvider as NextThemesProvider, useTheme } from 'next-themes';
import type { ThemeProviderProps } from 'next-themes/dist/types';
import { useFarmData } from '@/hooks/use-farm-data';

function ThemeSyncer() {
    const { farmData, loading } = useFarmData();
    const { setTheme } = useTheme();

    React.useEffect(() => {
        if (!loading && farmData.theme) {
            setTheme(farmData.theme);
        }
    }, [farmData.theme, loading, setTheme]);

    return null;
}

export function ThemeProvider({ children, ...props }: ThemeProviderProps) {
  return (
    <NextThemesProvider {...props}>
      <ThemeSyncer />
      {children}
    </NextThemesProvider>
  );
}
