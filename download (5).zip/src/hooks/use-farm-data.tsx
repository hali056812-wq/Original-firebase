'use client';

import React, { createContext, useContext, useState, ReactNode, useMemo, useCallback, useEffect } from 'react';
import { useUser, useFirestore, useDoc, useMemoFirebase, errorEmitter, FirestorePermissionError } from '@/firebase';
import { doc, setDoc } from 'firebase/firestore';
import { v4 as uuidv4 } from 'uuid';

export interface FinancialEntry {
    id: string;
    type: 'cost' | 'sale';
    amount: number;
    description: string;
    date: string;
    fieldId?: string | null;
}

export interface Field {
    id: string;
    name: string;
    size: number;
    sizeUnit: 'acres' | 'hectares';
    crop: string;
}

export interface Task {
    id: string;
    title: string;
    dueDate: string;
    status: 'pending' | 'completed';
    type: 'manual' | 'suggested';
    priority?: number;
    sourceRule?: string;
    fieldId?: string;
    note?: string;
}

interface FarmData {
    displayName?: string;
    expertise?: string;
    skills?: string[];
    theme?: 'light' | 'dark' | 'system';
    zone?: string;
    userType?: 'commercial' | 'hobbyist';

    // New properties for commercial setup
    farmName?: string;
    mainProducts?: string[];
    trackingStyle?: 'simple' | 'by_field';
    isFarmSetupComplete?: boolean;

    // Farm structure
    fields?: Field[];
    financialEntries?: FinancialEntry[];
    tasks?: Task[];

    // This flag is crucial for the Get Started flow
    isDataEntered: boolean;
    lastActivity?: string;
}

interface FarmCalculations {
    totalSales: number;
    totalCosts: number;
    totalProfit: number;
    fieldFinancials: {
        [fieldId: string]: {
            sales: number;
            costs: number;
            profit: number;
        }
    };
    generalFinancials: {
        sales: number;
        costs: number;
        profit: number;
    }
}

interface FarmDataContextType {
  farmData: FarmData;
  farmCalculations: FarmCalculations;
  isDataEntered: boolean;
  loading: boolean;
  updateFarmData: (data: Partial<FarmData>) => void;
  addFinancialEntry: (entry: Omit<FinancialEntry, 'id'>) => void;
  deleteFinancialEntry: (entryId: string) => void;
  addField: (field: Omit<Field, 'id'>) => void;
  deleteField: (fieldId: string) => void;
  addTask: (task: Omit<Task, 'id'>) => void;
  updateTask: (taskId: string, updates: Partial<Task>) => void;
  deleteTask: (taskId: string) => void;
  setIsDataEntered: (isEntered: boolean) => void;
  skipSetup: () => void;
  resetProfile: () => void;
}

const initialFarmData: FarmData = {
    displayName: '',
    expertise: '',
    skills: [],
    theme: 'system',
    zone: '',
    userType: 'commercial',
    fields: [],
    financialEntries: [],
    tasks: [],
    isDataEntered: false,
    farmName: '',
    mainProducts: [],
    trackingStyle: 'simple',
    isFarmSetupComplete: false,
    lastActivity: new Date().toISOString(),
};


const FarmDataContext = createContext<FarmDataContextType | undefined>(undefined);

export function FarmDataProvider({ children }: { children: ReactNode }) {
  const { user, isUserLoading } = useUser();
  const firestore = useFirestore();

  const [localFarmData, setLocalFarmData] = useState<FarmData>(initialFarmData);
  const [isDataEntered, setIsDataEntered] = useState(false);
  const [hasSkipped, setHasSkipped] = useState(false);

  const userProfileRef = useMemoFirebase(() => {
    if (user && firestore) {
      return doc(firestore, `users/${user.uid}/userProfile/main`);
    }
    return null;
  }, [user, firestore]);

  const { data: remoteFarmData, isLoading: loadingRemoteData } = useDoc<FarmData>(userProfileRef);
  
  useEffect(() => {
    if (isUserLoading || (user && loadingRemoteData)) {
      return;
    }
    
    if (user && remoteFarmData) {
        const dataWithInitializedFields = {
            ...initialFarmData,
            ...remoteFarmData,
            fields: remoteFarmData.fields || [],
            financialEntries: remoteFarmData.financialEntries || [],
            tasks: remoteFarmData.tasks || [],
            skills: remoteFarmData.skills || [],
            mainProducts: remoteFarmData.mainProducts || [],
        };
        setLocalFarmData(dataWithInitializedFields);
        setIsDataEntered(remoteFarmData.isDataEntered);
    } else if (user && !remoteFarmData) {
        // When a new user signs in and has no remote data,
        // sync their auth display name if available.
        const newInitialData = {
            ...initialFarmData,
            displayName: user.displayName || '',
        };
        setLocalFarmData(newInitialData);
        setIsDataEntered(false);
    } else if (!user) {
        setLocalFarmData(initialFarmData);
        setIsDataEntered(false);
        setHasSkipped(false);
    }
  }, [remoteFarmData, user, isUserLoading, loadingRemoteData]);


  const saveData = useCallback((dataToSave: Partial<FarmData>) => {
    if (userProfileRef && user) {
      const dataWithUser = { ...dataToSave, userId: user.uid, lastActivity: new Date().toISOString() };
      setDoc(userProfileRef, dataWithUser, { merge: true })
        .catch(async (serverError) => {
            const permissionError = new FirestorePermissionError({
                path: userProfileRef.path,
                operation: 'update',
                requestResourceData: dataWithUser,
            });
            errorEmitter.emit('permission-error', permissionError);
        });
    }
  }, [userProfileRef, user]);

  const updateFarmData = useCallback((data: Partial<FarmData>) => {
    setLocalFarmData(prevData => {
        const newData = { ...prevData, ...data };
        saveData(newData);
        return newData;
    });
  }, [saveData]);

  const addFinancialEntry = useCallback((entry: Omit<FinancialEntry, 'id'>) => {
    const newEntry = { ...entry, id: uuidv4() };
    const updatedEntries = [...(localFarmData.financialEntries || []), newEntry];
    updateFarmData({ financialEntries: updatedEntries });
  }, [localFarmData.financialEntries, updateFarmData]);

  const deleteFinancialEntry = useCallback((entryId: string) => {
    const updatedEntries = (localFarmData.financialEntries || []).filter(entry => entry.id !== entryId);
    updateFarmData({ financialEntries: updatedEntries });
  }, [localFarmData.financialEntries, updateFarmData]);

  const addField = useCallback((field: Omit<Field, 'id'>) => {
      const newField = { ...field, id: uuidv4() };
      const updatedFields = [...(localFarmData.fields || []), newField];
      updateFarmData({ fields: updatedFields });
  }, [localFarmData.fields, updateFarmData]);

  const deleteField = useCallback((fieldId: string) => {
      const updatedFields = (localFarmData.fields || []).filter(f => f.id !== fieldId);
      const updatedEntries = (localFarmData.financialEntries || []).filter(e => e.fieldId !== fieldId);
      updateFarmData({ fields: updatedFields, financialEntries: updatedEntries });
  }, [localFarmData.fields, localFarmData.financialEntries, updateFarmData]);

  const addTask = useCallback((task: Omit<Task, 'id'>) => {
      const newTask = { ...task, id: uuidv4() };
      const updatedTasks = [...(localFarmData.tasks || []), newTask];
      updateFarmData({ tasks: updatedTasks });
  }, [localFarmData.tasks, updateFarmData]);

  const updateTask = useCallback((taskId: string, updates: Partial<Task>) => {
    const updatedTasks = (localFarmData.tasks || []).map(task =>
      task.id === taskId ? { ...task, ...updates } : task
    );
    updateFarmData({ tasks: updatedTasks });
  }, [localFarmData.tasks, updateFarmData]);

  const deleteTask = useCallback((taskId: string) => {
    const updatedTasks = (localFarmData.tasks || []).filter(task => task.id !== taskId);
    updateFarmData({ tasks: updatedTasks });
  }, [localFarmData.tasks, updateFarmData]);
  
  const resetProfile = useCallback(() => {
    if (userProfileRef && user) {
        const resetData = { 
            ...initialFarmData, 
            userId: user.uid,
            displayName: user.displayName || '',
        };
        setDoc(userProfileRef, resetData)
            .then(() => {
                setLocalFarmData(resetData);
                setIsDataEntered(false);
            })
            .catch(async (serverError) => {
                const permissionError = new FirestorePermissionError({
                    path: userProfileRef.path,
                    operation: 'update',
                    requestResourceData: resetData,
                });
                errorEmitter.emit('permission-error', permissionError);
            });
    }
  }, [userProfileRef, user]);


  const farmCalculations = useMemo<FarmCalculations>(() => {
    const entries = localFarmData.financialEntries || [];
    let totalSales = 0;
    let totalCosts = 0;

    const fieldFinancials: FarmCalculations['fieldFinancials'] = {};
    const generalFinancials: FarmCalculations['generalFinancials'] = { sales: 0, costs: 0, profit: 0 };
    
    (localFarmData.fields || []).forEach(field => {
        fieldFinancials[field.id] = { sales: 0, costs: 0, profit: 0 };
    });

    for (const entry of entries) {
        if (entry.type === 'sale') {
            totalSales += entry.amount;
            if (entry.fieldId && fieldFinancials[entry.fieldId]) {
                fieldFinancials[entry.fieldId].sales += entry.amount;
            } else {
                generalFinancials.sales += entry.amount;
            }
        } else if (entry.type === 'cost') {
            totalCosts += entry.amount;
             if (entry.fieldId && fieldFinancials[entry.fieldId]) {
                fieldFinancials[entry.fieldId].costs += entry.amount;
            } else {
                generalFinancials.costs += entry.amount;
            }
        }
    }
    
    Object.keys(fieldFinancials).forEach(fieldId => {
        fieldFinancials[fieldId].profit = fieldFinancials[fieldId].sales - fieldFinancials[fieldId].costs;
    });

    generalFinancials.profit = generalFinancials.sales - generalFinancials.costs;

    return {
        totalSales,
        totalCosts,
        totalProfit: totalSales - totalCosts,
        fieldFinancials,
        generalFinancials
    };
  }, [localFarmData.financialEntries, localFarmData.fields]);

  const handleSetIsDataEntered = useCallback((isEntered: boolean) => {
    setIsDataEntered(isEntered);
    if (user) {
        updateFarmData({ isDataEntered: isEntered });
    }
  }, [updateFarmData, user]);

  const skipSetup = useCallback(() => {
    setIsDataEntered(true);
    setHasSkipped(true);
  }, []);

  const value = useMemo(() => ({
    farmData: localFarmData,
    farmCalculations,
    isDataEntered: isDataEntered || (hasSkipped && !user),
    loading: isUserLoading || (!!user && loadingRemoteData),
    updateFarmData,
    addFinancialEntry,
    deleteFinancialEntry,
    addField,
    deleteField,
    addTask,
    updateTask,
    deleteTask,
    setIsDataEntered: handleSetIsDataEntered,
    skipSetup,
    resetProfile,
  }), [localFarmData, farmCalculations, isDataEntered, hasSkipped, user, isUserLoading, loadingRemoteData, updateFarmData, addFinancialEntry, deleteFinancialEntry, addField, deleteField, addTask, updateTask, deleteTask, handleSetIsDataEntered, skipSetup, resetProfile]);

  return <FarmDataContext.Provider value={value}>{children}</FarmDataContext.Provider>;
}

export const useFarmData = (): FarmDataContextType => {
  const context = useContext(FarmDataContext);
  if (context === undefined) {
    throw new Error('useFarmData must be used within a FarmDataProvider');
  }
  return context;
};
