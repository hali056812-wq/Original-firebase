'use client';

import {
  createContext,
  useContext,
  ReactNode,
  useState,
  useEffect,
} from 'react';
import { useRouter } from 'next/navigation';
import {
  useUser as useFirebaseUser,
  useAuth as useFirebaseAuth,
} from '@/firebase';
import {
  createUserWithEmailAndPassword,
  signInWithEmailAndPassword,
  signOut,
  type User,
} from 'firebase/auth';

interface AuthContextType {
  user: User | null;
  loading: boolean;
  login: (email: string, pass: string) => Promise<void>;
  signup: (email: string, pass: string) => Promise<void>;
  logout: () => void;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export function AuthProvider({ children }: { children: ReactNode }) {
  const auth = useFirebaseAuth();
  const { user, isUserLoading, userError } = useFirebaseUser();
  const router = useRouter();
  const [loading, setLoading] = useState(isUserLoading);

  useEffect(() => {
    setLoading(isUserLoading);
  }, [isUserLoading]);

  const login = async (email: string, pass: string): Promise<void> => {
    await signInWithEmailAndPassword(auth, email, pass);
  };

  const signup = async (email: string, pass: string): Promise<void> => {
    await createUserWithEmailAndPassword(auth, email, pass);
  };

  const logout = () => {
    signOut(auth);
    router.push('/');
  };

  const value = { user, loading, login, signup, logout };

  return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>;
}

export const useAuth = (): AuthContextType => {
  const context = useContext(AuthContext);
  if (context === undefined) {
    // This hook is now a wrapper around the Firebase user state, but might be used
    // in places where the provider isn't available. We check the context from
    // the original mock provider.
    const auth = useFirebaseAuth();
    const { user, isUserLoading } = useFirebaseUser();
    const router = useRouter();

    const login = async (email: string, pass: string): Promise<void> => {
        await signInWithEmailAndPassword(auth, email, pass);
    };

    const signup = async (email: string, pass: string): Promise<void> => {
        await createUserWithEmailAndPassword(auth, email, pass);
    };

    const logout = () => {
        signOut(auth);
        router.push('/');
    };

    return { user, loading: isUserLoading, login, signup, logout };
  }
  return context;
};
